/**
 */
package FunctionalHazardAnalysis;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hazard</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.Hazard#getH_ID <em>HID</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.Hazard#getH_name <em>Hname</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.Hazard#getSG <em>SG</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.Hazard#getTC <em>TC</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.Hazard#getRelates_to <em>Relates to</em>}</li>
 * </ul>
 * </p>
 *
 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getHazard()
 * @model
 * @generated
 */
public interface Hazard extends EObject {
	/**
	 * Returns the value of the '<em><b>HID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>HID</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>HID</em>' attribute.
	 * @see #setH_ID(String)
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getHazard_H_ID()
	 * @model
	 * @generated
	 */
	String getH_ID();

	/**
	 * Sets the value of the '{@link FunctionalHazardAnalysis.Hazard#getH_ID <em>HID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>HID</em>' attribute.
	 * @see #getH_ID()
	 * @generated
	 */
	void setH_ID(String value);

	/**
	 * Returns the value of the '<em><b>Hname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hname</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hname</em>' attribute.
	 * @see #setH_name(String)
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getHazard_H_name()
	 * @model
	 * @generated
	 */
	String getH_name();

	/**
	 * Sets the value of the '{@link FunctionalHazardAnalysis.Hazard#getH_name <em>Hname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Hname</em>' attribute.
	 * @see #getH_name()
	 * @generated
	 */
	void setH_name(String value);

	/**
	 * Returns the value of the '<em><b>SG</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>SG</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>SG</em>' containment reference.
	 * @see #setSG(Safety_Goal)
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getHazard_SG()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Safety_Goal getSG();

	/**
	 * Sets the value of the '{@link FunctionalHazardAnalysis.Hazard#getSG <em>SG</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>SG</em>' containment reference.
	 * @see #getSG()
	 * @generated
	 */
	void setSG(Safety_Goal value);

	/**
	 * Returns the value of the '<em><b>TC</b></em>' containment reference list.
	 * The list contents are of type {@link FunctionalHazardAnalysis.Trigger_Conditions}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>TC</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>TC</em>' containment reference list.
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getHazard_TC()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Trigger_Conditions> getTC();

	/**
	 * Returns the value of the '<em><b>Relates to</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Relates to</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Relates to</em>' reference.
	 * @see #setRelates_to(Hazard_Inducing_Requirement)
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getHazard_Relates_to()
	 * @model required="true"
	 * @generated
	 */
	Hazard_Inducing_Requirement getRelates_to();

	/**
	 * Sets the value of the '{@link FunctionalHazardAnalysis.Hazard#getRelates_to <em>Relates to</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Relates to</em>' reference.
	 * @see #getRelates_to()
	 * @generated
	 */
	void setRelates_to(Hazard_Inducing_Requirement value);

} // Hazard
