/**
 */
package FunctionalHazardAnalysis;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Trigger Condition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.Trigger_Condition#getTC_ID <em>TC ID</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.Trigger_Condition#getTC_name <em>TC name</em>}</li>
 * </ul>
 * </p>
 *
 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getTrigger_Condition()
 * @model
 * @generated
 */
public interface Trigger_Condition extends EObject {
	/**
	 * Returns the value of the '<em><b>TC ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>TC ID</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>TC ID</em>' attribute.
	 * @see #setTC_ID(String)
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getTrigger_Condition_TC_ID()
	 * @model
	 * @generated
	 */
	String getTC_ID();

	/**
	 * Sets the value of the '{@link FunctionalHazardAnalysis.Trigger_Condition#getTC_ID <em>TC ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>TC ID</em>' attribute.
	 * @see #getTC_ID()
	 * @generated
	 */
	void setTC_ID(String value);

	/**
	 * Returns the value of the '<em><b>TC name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>TC name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>TC name</em>' attribute.
	 * @see #setTC_name(String)
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getTrigger_Condition_TC_name()
	 * @model
	 * @generated
	 */
	String getTC_name();

	/**
	 * Sets the value of the '{@link FunctionalHazardAnalysis.Trigger_Condition#getTC_name <em>TC name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>TC name</em>' attribute.
	 * @see #getTC_name()
	 * @generated
	 */
	void setTC_name(String value);

} // Trigger_Condition
