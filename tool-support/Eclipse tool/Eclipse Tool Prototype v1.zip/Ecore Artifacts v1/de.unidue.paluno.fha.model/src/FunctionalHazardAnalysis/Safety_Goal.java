/**
 */
package FunctionalHazardAnalysis;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Safety Goal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.Safety_Goal#getSG_name <em>SG name</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.Safety_Goal#getSG_ID <em>SG ID</em>}</li>
 * </ul>
 * </p>
 *
 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getSafety_Goal()
 * @model
 * @generated
 */
public interface Safety_Goal extends EObject {
	/**
	 * Returns the value of the '<em><b>SG name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>SG name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>SG name</em>' attribute.
	 * @see #setSG_name(String)
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getSafety_Goal_SG_name()
	 * @model
	 * @generated
	 */
	String getSG_name();

	/**
	 * Sets the value of the '{@link FunctionalHazardAnalysis.Safety_Goal#getSG_name <em>SG name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>SG name</em>' attribute.
	 * @see #getSG_name()
	 * @generated
	 */
	void setSG_name(String value);

	/**
	 * Returns the value of the '<em><b>SG ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>SG ID</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>SG ID</em>' attribute.
	 * @see #setSG_ID(String)
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getSafety_Goal_SG_ID()
	 * @model
	 * @generated
	 */
	String getSG_ID();

	/**
	 * Sets the value of the '{@link FunctionalHazardAnalysis.Safety_Goal#getSG_ID <em>SG ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>SG ID</em>' attribute.
	 * @see #getSG_ID()
	 * @generated
	 */
	void setSG_ID(String value);

} // Safety_Goal
