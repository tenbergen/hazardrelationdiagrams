/**
 */
package FunctionalHazardAnalysis;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ornode</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.ornode#getOr_id <em>Or id</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.ornode#getLinked_by <em>Linked by</em>}</li>
 * </ul>
 * </p>
 *
 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getornode()
 * @model
 * @generated
 */
public interface ornode extends EObject {
	/**
	 * Returns the value of the '<em><b>Or id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Or id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Or id</em>' attribute.
	 * @see #setOr_id(String)
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getornode_Or_id()
	 * @model
	 * @generated
	 */
	String getOr_id();

	/**
	 * Sets the value of the '{@link FunctionalHazardAnalysis.ornode#getOr_id <em>Or id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Or id</em>' attribute.
	 * @see #getOr_id()
	 * @generated
	 */
	void setOr_id(String value);

	/**
	 * Returns the value of the '<em><b>Linked by</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Linked by</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Linked by</em>' attribute.
	 * @see #setLinked_by(String)
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getornode_Linked_by()
	 * @model
	 * @generated
	 */
	String getLinked_by();

	/**
	 * Sets the value of the '{@link FunctionalHazardAnalysis.ornode#getLinked_by <em>Linked by</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Linked by</em>' attribute.
	 * @see #getLinked_by()
	 * @generated
	 */
	void setLinked_by(String value);

} // ornode
