/**
 */
package FunctionalHazardAnalysis.impl;

import FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage;
import FunctionalHazardAnalysis.Hazard;
import FunctionalHazardAnalysis.Hazard_Inducing_Requirement;
import FunctionalHazardAnalysis.Safety_Goal;
import FunctionalHazardAnalysis.Trigger_Conditions;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Hazard</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.impl.HazardImpl#getH_ID <em>HID</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.impl.HazardImpl#getH_name <em>Hname</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.impl.HazardImpl#getSG <em>SG</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.impl.HazardImpl#getTC <em>TC</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.impl.HazardImpl#getRelates_to <em>Relates to</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class HazardImpl extends MinimalEObjectImpl.Container implements Hazard {
	/**
	 * The default value of the '{@link #getH_ID() <em>HID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getH_ID()
	 * @generated
	 * @ordered
	 */
	protected static final String HID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getH_ID() <em>HID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getH_ID()
	 * @generated
	 * @ordered
	 */
	protected String h_ID = HID_EDEFAULT;

	/**
	 * The default value of the '{@link #getH_name() <em>Hname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getH_name()
	 * @generated
	 * @ordered
	 */
	protected static final String HNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getH_name() <em>Hname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getH_name()
	 * @generated
	 * @ordered
	 */
	protected String h_name = HNAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSG() <em>SG</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSG()
	 * @generated
	 * @ordered
	 */
	protected Safety_Goal sg;

	/**
	 * The cached value of the '{@link #getTC() <em>TC</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTC()
	 * @generated
	 * @ordered
	 */
	protected EList<Trigger_Conditions> tc;

	/**
	 * The cached value of the '{@link #getRelates_to() <em>Relates to</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRelates_to()
	 * @generated
	 * @ordered
	 */
	protected Hazard_Inducing_Requirement relates_to;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HazardImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FunctionalHazardAnalysisPackage.Literals.HAZARD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getH_ID() {
		return h_ID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setH_ID(String newH_ID) {
		String oldH_ID = h_ID;
		h_ID = newH_ID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FunctionalHazardAnalysisPackage.HAZARD__HID, oldH_ID, h_ID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getH_name() {
		return h_name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setH_name(String newH_name) {
		String oldH_name = h_name;
		h_name = newH_name;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FunctionalHazardAnalysisPackage.HAZARD__HNAME, oldH_name, h_name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Safety_Goal getSG() {
		return sg;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSG(Safety_Goal newSG, NotificationChain msgs) {
		Safety_Goal oldSG = sg;
		sg = newSG;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, FunctionalHazardAnalysisPackage.HAZARD__SG, oldSG, newSG);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSG(Safety_Goal newSG) {
		if (newSG != sg) {
			NotificationChain msgs = null;
			if (sg != null)
				msgs = ((InternalEObject)sg).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - FunctionalHazardAnalysisPackage.HAZARD__SG, null, msgs);
			if (newSG != null)
				msgs = ((InternalEObject)newSG).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - FunctionalHazardAnalysisPackage.HAZARD__SG, null, msgs);
			msgs = basicSetSG(newSG, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FunctionalHazardAnalysisPackage.HAZARD__SG, newSG, newSG));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Trigger_Conditions> getTC() {
		if (tc == null) {
			tc = new EObjectContainmentEList<Trigger_Conditions>(Trigger_Conditions.class, this, FunctionalHazardAnalysisPackage.HAZARD__TC);
		}
		return tc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Hazard_Inducing_Requirement getRelates_to() {
		if (relates_to != null && relates_to.eIsProxy()) {
			InternalEObject oldRelates_to = (InternalEObject)relates_to;
			relates_to = (Hazard_Inducing_Requirement)eResolveProxy(oldRelates_to);
			if (relates_to != oldRelates_to) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, FunctionalHazardAnalysisPackage.HAZARD__RELATES_TO, oldRelates_to, relates_to));
			}
		}
		return relates_to;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Hazard_Inducing_Requirement basicGetRelates_to() {
		return relates_to;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRelates_to(Hazard_Inducing_Requirement newRelates_to) {
		Hazard_Inducing_Requirement oldRelates_to = relates_to;
		relates_to = newRelates_to;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FunctionalHazardAnalysisPackage.HAZARD__RELATES_TO, oldRelates_to, relates_to));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.HAZARD__SG:
				return basicSetSG(null, msgs);
			case FunctionalHazardAnalysisPackage.HAZARD__TC:
				return ((InternalEList<?>)getTC()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.HAZARD__HID:
				return getH_ID();
			case FunctionalHazardAnalysisPackage.HAZARD__HNAME:
				return getH_name();
			case FunctionalHazardAnalysisPackage.HAZARD__SG:
				return getSG();
			case FunctionalHazardAnalysisPackage.HAZARD__TC:
				return getTC();
			case FunctionalHazardAnalysisPackage.HAZARD__RELATES_TO:
				if (resolve) return getRelates_to();
				return basicGetRelates_to();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.HAZARD__HID:
				setH_ID((String)newValue);
				return;
			case FunctionalHazardAnalysisPackage.HAZARD__HNAME:
				setH_name((String)newValue);
				return;
			case FunctionalHazardAnalysisPackage.HAZARD__SG:
				setSG((Safety_Goal)newValue);
				return;
			case FunctionalHazardAnalysisPackage.HAZARD__TC:
				getTC().clear();
				getTC().addAll((Collection<? extends Trigger_Conditions>)newValue);
				return;
			case FunctionalHazardAnalysisPackage.HAZARD__RELATES_TO:
				setRelates_to((Hazard_Inducing_Requirement)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.HAZARD__HID:
				setH_ID(HID_EDEFAULT);
				return;
			case FunctionalHazardAnalysisPackage.HAZARD__HNAME:
				setH_name(HNAME_EDEFAULT);
				return;
			case FunctionalHazardAnalysisPackage.HAZARD__SG:
				setSG((Safety_Goal)null);
				return;
			case FunctionalHazardAnalysisPackage.HAZARD__TC:
				getTC().clear();
				return;
			case FunctionalHazardAnalysisPackage.HAZARD__RELATES_TO:
				setRelates_to((Hazard_Inducing_Requirement)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.HAZARD__HID:
				return HID_EDEFAULT == null ? h_ID != null : !HID_EDEFAULT.equals(h_ID);
			case FunctionalHazardAnalysisPackage.HAZARD__HNAME:
				return HNAME_EDEFAULT == null ? h_name != null : !HNAME_EDEFAULT.equals(h_name);
			case FunctionalHazardAnalysisPackage.HAZARD__SG:
				return sg != null;
			case FunctionalHazardAnalysisPackage.HAZARD__TC:
				return tc != null && !tc.isEmpty();
			case FunctionalHazardAnalysisPackage.HAZARD__RELATES_TO:
				return relates_to != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (H_ID: ");
		result.append(h_ID);
		result.append(", H_name: ");
		result.append(h_name);
		result.append(')');
		return result.toString();
	}

} //HazardImpl
