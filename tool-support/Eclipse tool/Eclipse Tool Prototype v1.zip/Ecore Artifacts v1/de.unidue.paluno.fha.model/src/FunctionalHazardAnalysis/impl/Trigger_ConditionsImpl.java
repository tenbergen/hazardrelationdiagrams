/**
 */
package FunctionalHazardAnalysis.impl;

import FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage;
import FunctionalHazardAnalysis.Trigger_Condition;
import FunctionalHazardAnalysis.Trigger_Conditions;
import FunctionalHazardAnalysis.andnode;
import FunctionalHazardAnalysis.ornode;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Trigger Conditions</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.impl.Trigger_ConditionsImpl#getOr <em>Or</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.impl.Trigger_ConditionsImpl#getAnd <em>And</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.impl.Trigger_ConditionsImpl#getCond <em>Cond</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class Trigger_ConditionsImpl extends MinimalEObjectImpl.Container implements Trigger_Conditions {
	/**
	 * The cached value of the '{@link #getOr() <em>Or</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOr()
	 * @generated
	 * @ordered
	 */
	protected EList<ornode> or;

	/**
	 * The cached value of the '{@link #getAnd() <em>And</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnd()
	 * @generated
	 * @ordered
	 */
	protected EList<andnode> and;

	/**
	 * The cached value of the '{@link #getCond() <em>Cond</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCond()
	 * @generated
	 * @ordered
	 */
	protected EList<Trigger_Condition> cond;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Trigger_ConditionsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FunctionalHazardAnalysisPackage.Literals.TRIGGER_CONDITIONS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ornode> getOr() {
		if (or == null) {
			or = new EObjectContainmentEList<ornode>(ornode.class, this, FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__OR);
		}
		return or;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<andnode> getAnd() {
		if (and == null) {
			and = new EObjectContainmentEList<andnode>(andnode.class, this, FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__AND);
		}
		return and;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Trigger_Condition> getCond() {
		if (cond == null) {
			cond = new EObjectContainmentEList<Trigger_Condition>(Trigger_Condition.class, this, FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__COND);
		}
		return cond;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__OR:
				return ((InternalEList<?>)getOr()).basicRemove(otherEnd, msgs);
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__AND:
				return ((InternalEList<?>)getAnd()).basicRemove(otherEnd, msgs);
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__COND:
				return ((InternalEList<?>)getCond()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__OR:
				return getOr();
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__AND:
				return getAnd();
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__COND:
				return getCond();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__OR:
				getOr().clear();
				getOr().addAll((Collection<? extends ornode>)newValue);
				return;
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__AND:
				getAnd().clear();
				getAnd().addAll((Collection<? extends andnode>)newValue);
				return;
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__COND:
				getCond().clear();
				getCond().addAll((Collection<? extends Trigger_Condition>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__OR:
				getOr().clear();
				return;
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__AND:
				getAnd().clear();
				return;
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__COND:
				getCond().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__OR:
				return or != null && !or.isEmpty();
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__AND:
				return and != null && !and.isEmpty();
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS__COND:
				return cond != null && !cond.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //Trigger_ConditionsImpl
