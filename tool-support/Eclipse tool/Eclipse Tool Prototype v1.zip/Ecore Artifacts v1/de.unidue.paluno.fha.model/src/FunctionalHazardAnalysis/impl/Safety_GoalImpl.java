/**
 */
package FunctionalHazardAnalysis.impl;

import FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage;
import FunctionalHazardAnalysis.Safety_Goal;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Safety Goal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.impl.Safety_GoalImpl#getSG_name <em>SG name</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.impl.Safety_GoalImpl#getSG_ID <em>SG ID</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class Safety_GoalImpl extends MinimalEObjectImpl.Container implements Safety_Goal {
	/**
	 * The default value of the '{@link #getSG_name() <em>SG name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSG_name()
	 * @generated
	 * @ordered
	 */
	protected static final String SG_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSG_name() <em>SG name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSG_name()
	 * @generated
	 * @ordered
	 */
	protected String sG_name = SG_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getSG_ID() <em>SG ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSG_ID()
	 * @generated
	 * @ordered
	 */
	protected static final String SG_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSG_ID() <em>SG ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSG_ID()
	 * @generated
	 * @ordered
	 */
	protected String sG_ID = SG_ID_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Safety_GoalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FunctionalHazardAnalysisPackage.Literals.SAFETY_GOAL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSG_name() {
		return sG_name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSG_name(String newSG_name) {
		String oldSG_name = sG_name;
		sG_name = newSG_name;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FunctionalHazardAnalysisPackage.SAFETY_GOAL__SG_NAME, oldSG_name, sG_name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSG_ID() {
		return sG_ID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSG_ID(String newSG_ID) {
		String oldSG_ID = sG_ID;
		sG_ID = newSG_ID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FunctionalHazardAnalysisPackage.SAFETY_GOAL__SG_ID, oldSG_ID, sG_ID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.SAFETY_GOAL__SG_NAME:
				return getSG_name();
			case FunctionalHazardAnalysisPackage.SAFETY_GOAL__SG_ID:
				return getSG_ID();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.SAFETY_GOAL__SG_NAME:
				setSG_name((String)newValue);
				return;
			case FunctionalHazardAnalysisPackage.SAFETY_GOAL__SG_ID:
				setSG_ID((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.SAFETY_GOAL__SG_NAME:
				setSG_name(SG_NAME_EDEFAULT);
				return;
			case FunctionalHazardAnalysisPackage.SAFETY_GOAL__SG_ID:
				setSG_ID(SG_ID_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.SAFETY_GOAL__SG_NAME:
				return SG_NAME_EDEFAULT == null ? sG_name != null : !SG_NAME_EDEFAULT.equals(sG_name);
			case FunctionalHazardAnalysisPackage.SAFETY_GOAL__SG_ID:
				return SG_ID_EDEFAULT == null ? sG_ID != null : !SG_ID_EDEFAULT.equals(sG_ID);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (SG_name: ");
		result.append(sG_name);
		result.append(", SG_ID: ");
		result.append(sG_ID);
		result.append(')');
		return result.toString();
	}

} //Safety_GoalImpl
