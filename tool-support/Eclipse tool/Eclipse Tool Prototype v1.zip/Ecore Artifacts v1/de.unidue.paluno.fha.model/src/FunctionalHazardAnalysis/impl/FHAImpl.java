/**
 */
package FunctionalHazardAnalysis.impl;

import FunctionalHazardAnalysis.FHA;
import FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage;
import FunctionalHazardAnalysis.Hazard;
import FunctionalHazardAnalysis.Hazard_Inducing_Requirement;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>FHA</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.impl.FHAImpl#getH <em>H</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.impl.FHAImpl#getHir <em>Hir</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FHAImpl extends MinimalEObjectImpl.Container implements FHA {
	/**
	 * The cached value of the '{@link #getH() <em>H</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getH()
	 * @generated
	 * @ordered
	 */
	protected EList<Hazard> h;

	/**
	 * The cached value of the '{@link #getHir() <em>Hir</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHir()
	 * @generated
	 * @ordered
	 */
	protected EList<Hazard_Inducing_Requirement> hir;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FHAImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FunctionalHazardAnalysisPackage.Literals.FHA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Hazard> getH() {
		if (h == null) {
			h = new EObjectContainmentEList<Hazard>(Hazard.class, this, FunctionalHazardAnalysisPackage.FHA__H);
		}
		return h;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Hazard_Inducing_Requirement> getHir() {
		if (hir == null) {
			hir = new EObjectContainmentEList<Hazard_Inducing_Requirement>(Hazard_Inducing_Requirement.class, this, FunctionalHazardAnalysisPackage.FHA__HIR);
		}
		return hir;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.FHA__H:
				return ((InternalEList<?>)getH()).basicRemove(otherEnd, msgs);
			case FunctionalHazardAnalysisPackage.FHA__HIR:
				return ((InternalEList<?>)getHir()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.FHA__H:
				return getH();
			case FunctionalHazardAnalysisPackage.FHA__HIR:
				return getHir();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.FHA__H:
				getH().clear();
				getH().addAll((Collection<? extends Hazard>)newValue);
				return;
			case FunctionalHazardAnalysisPackage.FHA__HIR:
				getHir().clear();
				getHir().addAll((Collection<? extends Hazard_Inducing_Requirement>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.FHA__H:
				getH().clear();
				return;
			case FunctionalHazardAnalysisPackage.FHA__HIR:
				getHir().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.FHA__H:
				return h != null && !h.isEmpty();
			case FunctionalHazardAnalysisPackage.FHA__HIR:
				return hir != null && !hir.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //FHAImpl
