/**
 */
package FunctionalHazardAnalysis.impl;

import FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage;
import FunctionalHazardAnalysis.ornode;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>ornode</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.impl.ornodeImpl#getOr_id <em>Or id</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.impl.ornodeImpl#getLinked_by <em>Linked by</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ornodeImpl extends MinimalEObjectImpl.Container implements ornode {
	/**
	 * The default value of the '{@link #getOr_id() <em>Or id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOr_id()
	 * @generated
	 * @ordered
	 */
	protected static final String OR_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOr_id() <em>Or id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOr_id()
	 * @generated
	 * @ordered
	 */
	protected String or_id = OR_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getLinked_by() <em>Linked by</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLinked_by()
	 * @generated
	 * @ordered
	 */
	protected static final String LINKED_BY_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLinked_by() <em>Linked by</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLinked_by()
	 * @generated
	 * @ordered
	 */
	protected String linked_by = LINKED_BY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ornodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FunctionalHazardAnalysisPackage.Literals.ORNODE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOr_id() {
		return or_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOr_id(String newOr_id) {
		String oldOr_id = or_id;
		or_id = newOr_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FunctionalHazardAnalysisPackage.ORNODE__OR_ID, oldOr_id, or_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLinked_by() {
		return linked_by;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLinked_by(String newLinked_by) {
		String oldLinked_by = linked_by;
		linked_by = newLinked_by;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FunctionalHazardAnalysisPackage.ORNODE__LINKED_BY, oldLinked_by, linked_by));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.ORNODE__OR_ID:
				return getOr_id();
			case FunctionalHazardAnalysisPackage.ORNODE__LINKED_BY:
				return getLinked_by();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.ORNODE__OR_ID:
				setOr_id((String)newValue);
				return;
			case FunctionalHazardAnalysisPackage.ORNODE__LINKED_BY:
				setLinked_by((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.ORNODE__OR_ID:
				setOr_id(OR_ID_EDEFAULT);
				return;
			case FunctionalHazardAnalysisPackage.ORNODE__LINKED_BY:
				setLinked_by(LINKED_BY_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.ORNODE__OR_ID:
				return OR_ID_EDEFAULT == null ? or_id != null : !OR_ID_EDEFAULT.equals(or_id);
			case FunctionalHazardAnalysisPackage.ORNODE__LINKED_BY:
				return LINKED_BY_EDEFAULT == null ? linked_by != null : !LINKED_BY_EDEFAULT.equals(linked_by);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (or_id: ");
		result.append(or_id);
		result.append(", linked_by: ");
		result.append(linked_by);
		result.append(')');
		return result.toString();
	}

} //ornodeImpl
