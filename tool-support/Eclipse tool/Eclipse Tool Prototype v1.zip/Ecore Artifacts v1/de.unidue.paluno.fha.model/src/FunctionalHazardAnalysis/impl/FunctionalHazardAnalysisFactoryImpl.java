/**
 */
package FunctionalHazardAnalysis.impl;

import FunctionalHazardAnalysis.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class FunctionalHazardAnalysisFactoryImpl extends EFactoryImpl implements FunctionalHazardAnalysisFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static FunctionalHazardAnalysisFactory init() {
		try {
			FunctionalHazardAnalysisFactory theFunctionalHazardAnalysisFactory = (FunctionalHazardAnalysisFactory)EPackage.Registry.INSTANCE.getEFactory(FunctionalHazardAnalysisPackage.eNS_URI);
			if (theFunctionalHazardAnalysisFactory != null) {
				return theFunctionalHazardAnalysisFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new FunctionalHazardAnalysisFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionalHazardAnalysisFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case FunctionalHazardAnalysisPackage.FHA: return createFHA();
			case FunctionalHazardAnalysisPackage.HAZARD_INDUCING_REQUIREMENT: return createHazard_Inducing_Requirement();
			case FunctionalHazardAnalysisPackage.HAZARD: return createHazard();
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITION: return createTrigger_Condition();
			case FunctionalHazardAnalysisPackage.SAFETY_GOAL: return createSafety_Goal();
			case FunctionalHazardAnalysisPackage.ANDNODE: return createandnode();
			case FunctionalHazardAnalysisPackage.ORNODE: return createornode();
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITIONS: return createTrigger_Conditions();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FHA createFHA() {
		FHAImpl fha = new FHAImpl();
		return fha;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Hazard_Inducing_Requirement createHazard_Inducing_Requirement() {
		Hazard_Inducing_RequirementImpl hazard_Inducing_Requirement = new Hazard_Inducing_RequirementImpl();
		return hazard_Inducing_Requirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Hazard createHazard() {
		HazardImpl hazard = new HazardImpl();
		return hazard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Trigger_Condition createTrigger_Condition() {
		Trigger_ConditionImpl trigger_Condition = new Trigger_ConditionImpl();
		return trigger_Condition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Safety_Goal createSafety_Goal() {
		Safety_GoalImpl safety_Goal = new Safety_GoalImpl();
		return safety_Goal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public andnode createandnode() {
		andnodeImpl andnode = new andnodeImpl();
		return andnode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ornode createornode() {
		ornodeImpl ornode = new ornodeImpl();
		return ornode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Trigger_Conditions createTrigger_Conditions() {
		Trigger_ConditionsImpl trigger_Conditions = new Trigger_ConditionsImpl();
		return trigger_Conditions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionalHazardAnalysisPackage getFunctionalHazardAnalysisPackage() {
		return (FunctionalHazardAnalysisPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static FunctionalHazardAnalysisPackage getPackage() {
		return FunctionalHazardAnalysisPackage.eINSTANCE;
	}

} //FunctionalHazardAnalysisFactoryImpl
