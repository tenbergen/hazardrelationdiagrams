/**
 */
package FunctionalHazardAnalysis.impl;

import FunctionalHazardAnalysis.FunctionalHazardAnalysisFactory;
import FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage;
import FunctionalHazardAnalysis.Hazard;
import FunctionalHazardAnalysis.Hazard_Inducing_Requirement;
import FunctionalHazardAnalysis.Safety_Goal;
import FunctionalHazardAnalysis.Trigger_Condition;
import FunctionalHazardAnalysis.Trigger_Conditions;
import FunctionalHazardAnalysis.andnode;
import FunctionalHazardAnalysis.ornode;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class FunctionalHazardAnalysisPackageImpl extends EPackageImpl implements FunctionalHazardAnalysisPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fhaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hazard_Inducing_RequirementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hazardEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass trigger_ConditionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass safety_GoalEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass andnodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ornodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass trigger_ConditionsEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private FunctionalHazardAnalysisPackageImpl() {
		super(eNS_URI, FunctionalHazardAnalysisFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link FunctionalHazardAnalysisPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static FunctionalHazardAnalysisPackage init() {
		if (isInited) return (FunctionalHazardAnalysisPackage)EPackage.Registry.INSTANCE.getEPackage(FunctionalHazardAnalysisPackage.eNS_URI);

		// Obtain or create and register package
		FunctionalHazardAnalysisPackageImpl theFunctionalHazardAnalysisPackage = (FunctionalHazardAnalysisPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof FunctionalHazardAnalysisPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new FunctionalHazardAnalysisPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theFunctionalHazardAnalysisPackage.createPackageContents();

		// Initialize created meta-data
		theFunctionalHazardAnalysisPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theFunctionalHazardAnalysisPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(FunctionalHazardAnalysisPackage.eNS_URI, theFunctionalHazardAnalysisPackage);
		return theFunctionalHazardAnalysisPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFHA() {
		return fhaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFHA_H() {
		return (EReference)fhaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFHA_Hir() {
		return (EReference)fhaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHazard_Inducing_Requirement() {
		return hazard_Inducing_RequirementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHazard_Inducing_Requirement_Element_name() {
		return (EAttribute)hazard_Inducing_RequirementEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHazard() {
		return hazardEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHazard_H_ID() {
		return (EAttribute)hazardEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHazard_H_name() {
		return (EAttribute)hazardEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHazard_SG() {
		return (EReference)hazardEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHazard_TC() {
		return (EReference)hazardEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHazard_Relates_to() {
		return (EReference)hazardEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTrigger_Condition() {
		return trigger_ConditionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrigger_Condition_TC_ID() {
		return (EAttribute)trigger_ConditionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrigger_Condition_TC_name() {
		return (EAttribute)trigger_ConditionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSafety_Goal() {
		return safety_GoalEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSafety_Goal_SG_name() {
		return (EAttribute)safety_GoalEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSafety_Goal_SG_ID() {
		return (EAttribute)safety_GoalEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getandnode() {
		return andnodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getandnode_And_id() {
		return (EAttribute)andnodeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getandnode_Linked_by() {
		return (EAttribute)andnodeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getornode() {
		return ornodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getornode_Or_id() {
		return (EAttribute)ornodeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getornode_Linked_by() {
		return (EAttribute)ornodeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTrigger_Conditions() {
		return trigger_ConditionsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTrigger_Conditions_Or() {
		return (EReference)trigger_ConditionsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTrigger_Conditions_And() {
		return (EReference)trigger_ConditionsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTrigger_Conditions_Cond() {
		return (EReference)trigger_ConditionsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionalHazardAnalysisFactory getFunctionalHazardAnalysisFactory() {
		return (FunctionalHazardAnalysisFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		fhaEClass = createEClass(FHA);
		createEReference(fhaEClass, FHA__H);
		createEReference(fhaEClass, FHA__HIR);

		hazard_Inducing_RequirementEClass = createEClass(HAZARD_INDUCING_REQUIREMENT);
		createEAttribute(hazard_Inducing_RequirementEClass, HAZARD_INDUCING_REQUIREMENT__ELEMENT_NAME);

		hazardEClass = createEClass(HAZARD);
		createEAttribute(hazardEClass, HAZARD__HID);
		createEAttribute(hazardEClass, HAZARD__HNAME);
		createEReference(hazardEClass, HAZARD__SG);
		createEReference(hazardEClass, HAZARD__TC);
		createEReference(hazardEClass, HAZARD__RELATES_TO);

		trigger_ConditionEClass = createEClass(TRIGGER_CONDITION);
		createEAttribute(trigger_ConditionEClass, TRIGGER_CONDITION__TC_ID);
		createEAttribute(trigger_ConditionEClass, TRIGGER_CONDITION__TC_NAME);

		safety_GoalEClass = createEClass(SAFETY_GOAL);
		createEAttribute(safety_GoalEClass, SAFETY_GOAL__SG_NAME);
		createEAttribute(safety_GoalEClass, SAFETY_GOAL__SG_ID);

		andnodeEClass = createEClass(ANDNODE);
		createEAttribute(andnodeEClass, ANDNODE__AND_ID);
		createEAttribute(andnodeEClass, ANDNODE__LINKED_BY);

		ornodeEClass = createEClass(ORNODE);
		createEAttribute(ornodeEClass, ORNODE__OR_ID);
		createEAttribute(ornodeEClass, ORNODE__LINKED_BY);

		trigger_ConditionsEClass = createEClass(TRIGGER_CONDITIONS);
		createEReference(trigger_ConditionsEClass, TRIGGER_CONDITIONS__OR);
		createEReference(trigger_ConditionsEClass, TRIGGER_CONDITIONS__AND);
		createEReference(trigger_ConditionsEClass, TRIGGER_CONDITIONS__COND);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes, features, and operations; add parameters
		initEClass(fhaEClass, FunctionalHazardAnalysis.FHA.class, "FHA", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFHA_H(), this.getHazard(), null, "H", null, 1, -1, FunctionalHazardAnalysis.FHA.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFHA_Hir(), this.getHazard_Inducing_Requirement(), null, "hir", null, 1, -1, FunctionalHazardAnalysis.FHA.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(hazard_Inducing_RequirementEClass, Hazard_Inducing_Requirement.class, "Hazard_Inducing_Requirement", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getHazard_Inducing_Requirement_Element_name(), ecorePackage.getEString(), "Element_name", null, 0, 1, Hazard_Inducing_Requirement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(hazardEClass, Hazard.class, "Hazard", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getHazard_H_ID(), ecorePackage.getEString(), "H_ID", null, 0, 1, Hazard.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getHazard_H_name(), ecorePackage.getEString(), "H_name", null, 0, 1, Hazard.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHazard_SG(), this.getSafety_Goal(), null, "SG", null, 1, 1, Hazard.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHazard_TC(), this.getTrigger_Conditions(), null, "TC", null, 1, -1, Hazard.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHazard_Relates_to(), this.getHazard_Inducing_Requirement(), null, "relates_to", null, 1, 1, Hazard.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(trigger_ConditionEClass, Trigger_Condition.class, "Trigger_Condition", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTrigger_Condition_TC_ID(), ecorePackage.getEString(), "TC_ID", null, 0, 1, Trigger_Condition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrigger_Condition_TC_name(), ecorePackage.getEString(), "TC_name", null, 0, 1, Trigger_Condition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(safety_GoalEClass, Safety_Goal.class, "Safety_Goal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSafety_Goal_SG_name(), ecorePackage.getEString(), "SG_name", null, 0, 1, Safety_Goal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSafety_Goal_SG_ID(), ecorePackage.getEString(), "SG_ID", null, 0, 1, Safety_Goal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(andnodeEClass, andnode.class, "andnode", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getandnode_And_id(), ecorePackage.getEString(), "and_id", null, 0, 1, andnode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getandnode_Linked_by(), ecorePackage.getEString(), "linked_by", null, 0, 1, andnode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ornodeEClass, ornode.class, "ornode", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getornode_Or_id(), ecorePackage.getEString(), "or_id", null, 0, 1, ornode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getornode_Linked_by(), ecorePackage.getEString(), "linked_by", null, 0, 1, ornode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(trigger_ConditionsEClass, Trigger_Conditions.class, "Trigger_Conditions", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTrigger_Conditions_Or(), this.getornode(), null, "or", null, 0, -1, Trigger_Conditions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTrigger_Conditions_And(), this.getandnode(), null, "and", null, 0, -1, Trigger_Conditions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTrigger_Conditions_Cond(), this.getTrigger_Condition(), null, "cond", null, 1, -1, Trigger_Conditions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //FunctionalHazardAnalysisPackageImpl
