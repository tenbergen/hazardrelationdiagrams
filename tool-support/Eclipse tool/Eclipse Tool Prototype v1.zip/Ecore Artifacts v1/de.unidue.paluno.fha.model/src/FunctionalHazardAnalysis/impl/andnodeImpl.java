/**
 */
package FunctionalHazardAnalysis.impl;

import FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage;
import FunctionalHazardAnalysis.andnode;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>andnode</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.impl.andnodeImpl#getAnd_id <em>And id</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.impl.andnodeImpl#getLinked_by <em>Linked by</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class andnodeImpl extends MinimalEObjectImpl.Container implements andnode {
	/**
	 * The default value of the '{@link #getAnd_id() <em>And id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnd_id()
	 * @generated
	 * @ordered
	 */
	protected static final String AND_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAnd_id() <em>And id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnd_id()
	 * @generated
	 * @ordered
	 */
	protected String and_id = AND_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getLinked_by() <em>Linked by</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLinked_by()
	 * @generated
	 * @ordered
	 */
	protected static final String LINKED_BY_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLinked_by() <em>Linked by</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLinked_by()
	 * @generated
	 * @ordered
	 */
	protected String linked_by = LINKED_BY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected andnodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FunctionalHazardAnalysisPackage.Literals.ANDNODE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAnd_id() {
		return and_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAnd_id(String newAnd_id) {
		String oldAnd_id = and_id;
		and_id = newAnd_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FunctionalHazardAnalysisPackage.ANDNODE__AND_ID, oldAnd_id, and_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLinked_by() {
		return linked_by;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLinked_by(String newLinked_by) {
		String oldLinked_by = linked_by;
		linked_by = newLinked_by;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FunctionalHazardAnalysisPackage.ANDNODE__LINKED_BY, oldLinked_by, linked_by));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.ANDNODE__AND_ID:
				return getAnd_id();
			case FunctionalHazardAnalysisPackage.ANDNODE__LINKED_BY:
				return getLinked_by();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.ANDNODE__AND_ID:
				setAnd_id((String)newValue);
				return;
			case FunctionalHazardAnalysisPackage.ANDNODE__LINKED_BY:
				setLinked_by((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.ANDNODE__AND_ID:
				setAnd_id(AND_ID_EDEFAULT);
				return;
			case FunctionalHazardAnalysisPackage.ANDNODE__LINKED_BY:
				setLinked_by(LINKED_BY_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.ANDNODE__AND_ID:
				return AND_ID_EDEFAULT == null ? and_id != null : !AND_ID_EDEFAULT.equals(and_id);
			case FunctionalHazardAnalysisPackage.ANDNODE__LINKED_BY:
				return LINKED_BY_EDEFAULT == null ? linked_by != null : !LINKED_BY_EDEFAULT.equals(linked_by);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (and_id: ");
		result.append(and_id);
		result.append(", linked_by: ");
		result.append(linked_by);
		result.append(')');
		return result.toString();
	}

} //andnodeImpl
