/**
 */
package FunctionalHazardAnalysis.impl;

import FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage;
import FunctionalHazardAnalysis.Trigger_Condition;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Trigger Condition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.impl.Trigger_ConditionImpl#getTC_ID <em>TC ID</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.impl.Trigger_ConditionImpl#getTC_name <em>TC name</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class Trigger_ConditionImpl extends MinimalEObjectImpl.Container implements Trigger_Condition {
	/**
	 * The default value of the '{@link #getTC_ID() <em>TC ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTC_ID()
	 * @generated
	 * @ordered
	 */
	protected static final String TC_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTC_ID() <em>TC ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTC_ID()
	 * @generated
	 * @ordered
	 */
	protected String tC_ID = TC_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getTC_name() <em>TC name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTC_name()
	 * @generated
	 * @ordered
	 */
	protected static final String TC_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTC_name() <em>TC name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTC_name()
	 * @generated
	 * @ordered
	 */
	protected String tC_name = TC_NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Trigger_ConditionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FunctionalHazardAnalysisPackage.Literals.TRIGGER_CONDITION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTC_ID() {
		return tC_ID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTC_ID(String newTC_ID) {
		String oldTC_ID = tC_ID;
		tC_ID = newTC_ID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FunctionalHazardAnalysisPackage.TRIGGER_CONDITION__TC_ID, oldTC_ID, tC_ID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTC_name() {
		return tC_name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTC_name(String newTC_name) {
		String oldTC_name = tC_name;
		tC_name = newTC_name;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FunctionalHazardAnalysisPackage.TRIGGER_CONDITION__TC_NAME, oldTC_name, tC_name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITION__TC_ID:
				return getTC_ID();
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITION__TC_NAME:
				return getTC_name();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITION__TC_ID:
				setTC_ID((String)newValue);
				return;
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITION__TC_NAME:
				setTC_name((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITION__TC_ID:
				setTC_ID(TC_ID_EDEFAULT);
				return;
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITION__TC_NAME:
				setTC_name(TC_NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITION__TC_ID:
				return TC_ID_EDEFAULT == null ? tC_ID != null : !TC_ID_EDEFAULT.equals(tC_ID);
			case FunctionalHazardAnalysisPackage.TRIGGER_CONDITION__TC_NAME:
				return TC_NAME_EDEFAULT == null ? tC_name != null : !TC_NAME_EDEFAULT.equals(tC_name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (TC_ID: ");
		result.append(tC_ID);
		result.append(", TC_name: ");
		result.append(tC_name);
		result.append(')');
		return result.toString();
	}

} //Trigger_ConditionImpl
