/**
 */
package FunctionalHazardAnalysis;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Trigger Conditions</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.Trigger_Conditions#getOr <em>Or</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.Trigger_Conditions#getAnd <em>And</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.Trigger_Conditions#getCond <em>Cond</em>}</li>
 * </ul>
 * </p>
 *
 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getTrigger_Conditions()
 * @model
 * @generated
 */
public interface Trigger_Conditions extends EObject {
	/**
	 * Returns the value of the '<em><b>Or</b></em>' containment reference list.
	 * The list contents are of type {@link FunctionalHazardAnalysis.ornode}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Or</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Or</em>' containment reference list.
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getTrigger_Conditions_Or()
	 * @model containment="true"
	 * @generated
	 */
	EList<ornode> getOr();

	/**
	 * Returns the value of the '<em><b>And</b></em>' containment reference list.
	 * The list contents are of type {@link FunctionalHazardAnalysis.andnode}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>And</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>And</em>' containment reference list.
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getTrigger_Conditions_And()
	 * @model containment="true"
	 * @generated
	 */
	EList<andnode> getAnd();

	/**
	 * Returns the value of the '<em><b>Cond</b></em>' containment reference list.
	 * The list contents are of type {@link FunctionalHazardAnalysis.Trigger_Condition}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Cond</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cond</em>' containment reference list.
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getTrigger_Conditions_Cond()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Trigger_Condition> getCond();

} // Trigger_Conditions
