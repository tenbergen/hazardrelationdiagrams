/**
 */
package FunctionalHazardAnalysis;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage
 * @generated
 */
public interface FunctionalHazardAnalysisFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	FunctionalHazardAnalysisFactory eINSTANCE = FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>FHA</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>FHA</em>'.
	 * @generated
	 */
	FHA createFHA();

	/**
	 * Returns a new object of class '<em>Hazard Inducing Requirement</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hazard Inducing Requirement</em>'.
	 * @generated
	 */
	Hazard_Inducing_Requirement createHazard_Inducing_Requirement();

	/**
	 * Returns a new object of class '<em>Hazard</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hazard</em>'.
	 * @generated
	 */
	Hazard createHazard();

	/**
	 * Returns a new object of class '<em>Trigger Condition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Trigger Condition</em>'.
	 * @generated
	 */
	Trigger_Condition createTrigger_Condition();

	/**
	 * Returns a new object of class '<em>Safety Goal</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Safety Goal</em>'.
	 * @generated
	 */
	Safety_Goal createSafety_Goal();

	/**
	 * Returns a new object of class '<em>andnode</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>andnode</em>'.
	 * @generated
	 */
	andnode createandnode();

	/**
	 * Returns a new object of class '<em>ornode</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>ornode</em>'.
	 * @generated
	 */
	ornode createornode();

	/**
	 * Returns a new object of class '<em>Trigger Conditions</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Trigger Conditions</em>'.
	 * @generated
	 */
	Trigger_Conditions createTrigger_Conditions();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	FunctionalHazardAnalysisPackage getFunctionalHazardAnalysisPackage();

} //FunctionalHazardAnalysisFactory
