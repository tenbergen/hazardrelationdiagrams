/**
 */
package FunctionalHazardAnalysis;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>andnode</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.andnode#getAnd_id <em>And id</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.andnode#getLinked_by <em>Linked by</em>}</li>
 * </ul>
 * </p>
 *
 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getandnode()
 * @model
 * @generated
 */
public interface andnode extends EObject {
	/**
	 * Returns the value of the '<em><b>And id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>And id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>And id</em>' attribute.
	 * @see #setAnd_id(String)
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getandnode_And_id()
	 * @model
	 * @generated
	 */
	String getAnd_id();

	/**
	 * Sets the value of the '{@link FunctionalHazardAnalysis.andnode#getAnd_id <em>And id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>And id</em>' attribute.
	 * @see #getAnd_id()
	 * @generated
	 */
	void setAnd_id(String value);

	/**
	 * Returns the value of the '<em><b>Linked by</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Linked by</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Linked by</em>' attribute.
	 * @see #setLinked_by(String)
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getandnode_Linked_by()
	 * @model
	 * @generated
	 */
	String getLinked_by();

	/**
	 * Sets the value of the '{@link FunctionalHazardAnalysis.andnode#getLinked_by <em>Linked by</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Linked by</em>' attribute.
	 * @see #getLinked_by()
	 * @generated
	 */
	void setLinked_by(String value);

} // andnode
