/**
 */
package FunctionalHazardAnalysis;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>FHA</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.FHA#getH <em>H</em>}</li>
 *   <li>{@link FunctionalHazardAnalysis.FHA#getHir <em>Hir</em>}</li>
 * </ul>
 * </p>
 *
 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getFHA()
 * @model
 * @generated
 */
public interface FHA extends EObject {
	/**
	 * Returns the value of the '<em><b>H</b></em>' containment reference list.
	 * The list contents are of type {@link FunctionalHazardAnalysis.Hazard}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>H</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>H</em>' containment reference list.
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getFHA_H()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Hazard> getH();

	/**
	 * Returns the value of the '<em><b>Hir</b></em>' containment reference list.
	 * The list contents are of type {@link FunctionalHazardAnalysis.Hazard_Inducing_Requirement}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hir</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hir</em>' containment reference list.
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getFHA_Hir()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Hazard_Inducing_Requirement> getHir();

} // FHA
