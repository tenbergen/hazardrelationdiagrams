/**
 */
package FunctionalHazardAnalysis;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisFactory
 * @model kind="package"
 * @generated
 */
public interface FunctionalHazardAnalysisPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "FunctionalHazardAnalysis";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.paluno.de/fha";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "FunctionalHazardAnalysis";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	FunctionalHazardAnalysisPackage eINSTANCE = FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl.init();

	/**
	 * The meta object id for the '{@link FunctionalHazardAnalysis.impl.FHAImpl <em>FHA</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FunctionalHazardAnalysis.impl.FHAImpl
	 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getFHA()
	 * @generated
	 */
	int FHA = 0;

	/**
	 * The feature id for the '<em><b>H</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FHA__H = 0;

	/**
	 * The feature id for the '<em><b>Hir</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FHA__HIR = 1;

	/**
	 * The number of structural features of the '<em>FHA</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FHA_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>FHA</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FHA_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link FunctionalHazardAnalysis.impl.Hazard_Inducing_RequirementImpl <em>Hazard Inducing Requirement</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FunctionalHazardAnalysis.impl.Hazard_Inducing_RequirementImpl
	 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getHazard_Inducing_Requirement()
	 * @generated
	 */
	int HAZARD_INDUCING_REQUIREMENT = 1;

	/**
	 * The feature id for the '<em><b>Element name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HAZARD_INDUCING_REQUIREMENT__ELEMENT_NAME = 0;

	/**
	 * The number of structural features of the '<em>Hazard Inducing Requirement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HAZARD_INDUCING_REQUIREMENT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Hazard Inducing Requirement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HAZARD_INDUCING_REQUIREMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link FunctionalHazardAnalysis.impl.HazardImpl <em>Hazard</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FunctionalHazardAnalysis.impl.HazardImpl
	 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getHazard()
	 * @generated
	 */
	int HAZARD = 2;

	/**
	 * The feature id for the '<em><b>HID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HAZARD__HID = 0;

	/**
	 * The feature id for the '<em><b>Hname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HAZARD__HNAME = 1;

	/**
	 * The feature id for the '<em><b>SG</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HAZARD__SG = 2;

	/**
	 * The feature id for the '<em><b>TC</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HAZARD__TC = 3;

	/**
	 * The feature id for the '<em><b>Relates to</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HAZARD__RELATES_TO = 4;

	/**
	 * The number of structural features of the '<em>Hazard</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HAZARD_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Hazard</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HAZARD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link FunctionalHazardAnalysis.impl.Trigger_ConditionImpl <em>Trigger Condition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FunctionalHazardAnalysis.impl.Trigger_ConditionImpl
	 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getTrigger_Condition()
	 * @generated
	 */
	int TRIGGER_CONDITION = 3;

	/**
	 * The feature id for the '<em><b>TC ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER_CONDITION__TC_ID = 0;

	/**
	 * The feature id for the '<em><b>TC name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER_CONDITION__TC_NAME = 1;

	/**
	 * The number of structural features of the '<em>Trigger Condition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER_CONDITION_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Trigger Condition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER_CONDITION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link FunctionalHazardAnalysis.impl.Safety_GoalImpl <em>Safety Goal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FunctionalHazardAnalysis.impl.Safety_GoalImpl
	 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getSafety_Goal()
	 * @generated
	 */
	int SAFETY_GOAL = 4;

	/**
	 * The feature id for the '<em><b>SG name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SAFETY_GOAL__SG_NAME = 0;

	/**
	 * The feature id for the '<em><b>SG ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SAFETY_GOAL__SG_ID = 1;

	/**
	 * The number of structural features of the '<em>Safety Goal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SAFETY_GOAL_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Safety Goal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SAFETY_GOAL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link FunctionalHazardAnalysis.impl.andnodeImpl <em>andnode</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FunctionalHazardAnalysis.impl.andnodeImpl
	 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getandnode()
	 * @generated
	 */
	int ANDNODE = 5;

	/**
	 * The feature id for the '<em><b>And id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANDNODE__AND_ID = 0;

	/**
	 * The feature id for the '<em><b>Linked by</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANDNODE__LINKED_BY = 1;

	/**
	 * The number of structural features of the '<em>andnode</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANDNODE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>andnode</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANDNODE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link FunctionalHazardAnalysis.impl.ornodeImpl <em>ornode</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FunctionalHazardAnalysis.impl.ornodeImpl
	 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getornode()
	 * @generated
	 */
	int ORNODE = 6;

	/**
	 * The feature id for the '<em><b>Or id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORNODE__OR_ID = 0;

	/**
	 * The feature id for the '<em><b>Linked by</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORNODE__LINKED_BY = 1;

	/**
	 * The number of structural features of the '<em>ornode</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORNODE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>ornode</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORNODE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link FunctionalHazardAnalysis.impl.Trigger_ConditionsImpl <em>Trigger Conditions</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FunctionalHazardAnalysis.impl.Trigger_ConditionsImpl
	 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getTrigger_Conditions()
	 * @generated
	 */
	int TRIGGER_CONDITIONS = 7;

	/**
	 * The feature id for the '<em><b>Or</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER_CONDITIONS__OR = 0;

	/**
	 * The feature id for the '<em><b>And</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER_CONDITIONS__AND = 1;

	/**
	 * The feature id for the '<em><b>Cond</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER_CONDITIONS__COND = 2;

	/**
	 * The number of structural features of the '<em>Trigger Conditions</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER_CONDITIONS_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Trigger Conditions</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER_CONDITIONS_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link FunctionalHazardAnalysis.FHA <em>FHA</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>FHA</em>'.
	 * @see FunctionalHazardAnalysis.FHA
	 * @generated
	 */
	EClass getFHA();

	/**
	 * Returns the meta object for the containment reference list '{@link FunctionalHazardAnalysis.FHA#getH <em>H</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>H</em>'.
	 * @see FunctionalHazardAnalysis.FHA#getH()
	 * @see #getFHA()
	 * @generated
	 */
	EReference getFHA_H();

	/**
	 * Returns the meta object for the containment reference list '{@link FunctionalHazardAnalysis.FHA#getHir <em>Hir</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Hir</em>'.
	 * @see FunctionalHazardAnalysis.FHA#getHir()
	 * @see #getFHA()
	 * @generated
	 */
	EReference getFHA_Hir();

	/**
	 * Returns the meta object for class '{@link FunctionalHazardAnalysis.Hazard_Inducing_Requirement <em>Hazard Inducing Requirement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Hazard Inducing Requirement</em>'.
	 * @see FunctionalHazardAnalysis.Hazard_Inducing_Requirement
	 * @generated
	 */
	EClass getHazard_Inducing_Requirement();

	/**
	 * Returns the meta object for the attribute '{@link FunctionalHazardAnalysis.Hazard_Inducing_Requirement#getElement_name <em>Element name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Element name</em>'.
	 * @see FunctionalHazardAnalysis.Hazard_Inducing_Requirement#getElement_name()
	 * @see #getHazard_Inducing_Requirement()
	 * @generated
	 */
	EAttribute getHazard_Inducing_Requirement_Element_name();

	/**
	 * Returns the meta object for class '{@link FunctionalHazardAnalysis.Hazard <em>Hazard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Hazard</em>'.
	 * @see FunctionalHazardAnalysis.Hazard
	 * @generated
	 */
	EClass getHazard();

	/**
	 * Returns the meta object for the attribute '{@link FunctionalHazardAnalysis.Hazard#getH_ID <em>HID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>HID</em>'.
	 * @see FunctionalHazardAnalysis.Hazard#getH_ID()
	 * @see #getHazard()
	 * @generated
	 */
	EAttribute getHazard_H_ID();

	/**
	 * Returns the meta object for the attribute '{@link FunctionalHazardAnalysis.Hazard#getH_name <em>Hname</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Hname</em>'.
	 * @see FunctionalHazardAnalysis.Hazard#getH_name()
	 * @see #getHazard()
	 * @generated
	 */
	EAttribute getHazard_H_name();

	/**
	 * Returns the meta object for the containment reference '{@link FunctionalHazardAnalysis.Hazard#getSG <em>SG</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>SG</em>'.
	 * @see FunctionalHazardAnalysis.Hazard#getSG()
	 * @see #getHazard()
	 * @generated
	 */
	EReference getHazard_SG();

	/**
	 * Returns the meta object for the containment reference list '{@link FunctionalHazardAnalysis.Hazard#getTC <em>TC</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>TC</em>'.
	 * @see FunctionalHazardAnalysis.Hazard#getTC()
	 * @see #getHazard()
	 * @generated
	 */
	EReference getHazard_TC();

	/**
	 * Returns the meta object for the reference '{@link FunctionalHazardAnalysis.Hazard#getRelates_to <em>Relates to</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Relates to</em>'.
	 * @see FunctionalHazardAnalysis.Hazard#getRelates_to()
	 * @see #getHazard()
	 * @generated
	 */
	EReference getHazard_Relates_to();

	/**
	 * Returns the meta object for class '{@link FunctionalHazardAnalysis.Trigger_Condition <em>Trigger Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Trigger Condition</em>'.
	 * @see FunctionalHazardAnalysis.Trigger_Condition
	 * @generated
	 */
	EClass getTrigger_Condition();

	/**
	 * Returns the meta object for the attribute '{@link FunctionalHazardAnalysis.Trigger_Condition#getTC_ID <em>TC ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>TC ID</em>'.
	 * @see FunctionalHazardAnalysis.Trigger_Condition#getTC_ID()
	 * @see #getTrigger_Condition()
	 * @generated
	 */
	EAttribute getTrigger_Condition_TC_ID();

	/**
	 * Returns the meta object for the attribute '{@link FunctionalHazardAnalysis.Trigger_Condition#getTC_name <em>TC name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>TC name</em>'.
	 * @see FunctionalHazardAnalysis.Trigger_Condition#getTC_name()
	 * @see #getTrigger_Condition()
	 * @generated
	 */
	EAttribute getTrigger_Condition_TC_name();

	/**
	 * Returns the meta object for class '{@link FunctionalHazardAnalysis.Safety_Goal <em>Safety Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Safety Goal</em>'.
	 * @see FunctionalHazardAnalysis.Safety_Goal
	 * @generated
	 */
	EClass getSafety_Goal();

	/**
	 * Returns the meta object for the attribute '{@link FunctionalHazardAnalysis.Safety_Goal#getSG_name <em>SG name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>SG name</em>'.
	 * @see FunctionalHazardAnalysis.Safety_Goal#getSG_name()
	 * @see #getSafety_Goal()
	 * @generated
	 */
	EAttribute getSafety_Goal_SG_name();

	/**
	 * Returns the meta object for the attribute '{@link FunctionalHazardAnalysis.Safety_Goal#getSG_ID <em>SG ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>SG ID</em>'.
	 * @see FunctionalHazardAnalysis.Safety_Goal#getSG_ID()
	 * @see #getSafety_Goal()
	 * @generated
	 */
	EAttribute getSafety_Goal_SG_ID();

	/**
	 * Returns the meta object for class '{@link FunctionalHazardAnalysis.andnode <em>andnode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>andnode</em>'.
	 * @see FunctionalHazardAnalysis.andnode
	 * @generated
	 */
	EClass getandnode();

	/**
	 * Returns the meta object for the attribute '{@link FunctionalHazardAnalysis.andnode#getAnd_id <em>And id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>And id</em>'.
	 * @see FunctionalHazardAnalysis.andnode#getAnd_id()
	 * @see #getandnode()
	 * @generated
	 */
	EAttribute getandnode_And_id();

	/**
	 * Returns the meta object for the attribute '{@link FunctionalHazardAnalysis.andnode#getLinked_by <em>Linked by</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Linked by</em>'.
	 * @see FunctionalHazardAnalysis.andnode#getLinked_by()
	 * @see #getandnode()
	 * @generated
	 */
	EAttribute getandnode_Linked_by();

	/**
	 * Returns the meta object for class '{@link FunctionalHazardAnalysis.ornode <em>ornode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>ornode</em>'.
	 * @see FunctionalHazardAnalysis.ornode
	 * @generated
	 */
	EClass getornode();

	/**
	 * Returns the meta object for the attribute '{@link FunctionalHazardAnalysis.ornode#getOr_id <em>Or id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Or id</em>'.
	 * @see FunctionalHazardAnalysis.ornode#getOr_id()
	 * @see #getornode()
	 * @generated
	 */
	EAttribute getornode_Or_id();

	/**
	 * Returns the meta object for the attribute '{@link FunctionalHazardAnalysis.ornode#getLinked_by <em>Linked by</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Linked by</em>'.
	 * @see FunctionalHazardAnalysis.ornode#getLinked_by()
	 * @see #getornode()
	 * @generated
	 */
	EAttribute getornode_Linked_by();

	/**
	 * Returns the meta object for class '{@link FunctionalHazardAnalysis.Trigger_Conditions <em>Trigger Conditions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Trigger Conditions</em>'.
	 * @see FunctionalHazardAnalysis.Trigger_Conditions
	 * @generated
	 */
	EClass getTrigger_Conditions();

	/**
	 * Returns the meta object for the containment reference list '{@link FunctionalHazardAnalysis.Trigger_Conditions#getOr <em>Or</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Or</em>'.
	 * @see FunctionalHazardAnalysis.Trigger_Conditions#getOr()
	 * @see #getTrigger_Conditions()
	 * @generated
	 */
	EReference getTrigger_Conditions_Or();

	/**
	 * Returns the meta object for the containment reference list '{@link FunctionalHazardAnalysis.Trigger_Conditions#getAnd <em>And</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>And</em>'.
	 * @see FunctionalHazardAnalysis.Trigger_Conditions#getAnd()
	 * @see #getTrigger_Conditions()
	 * @generated
	 */
	EReference getTrigger_Conditions_And();

	/**
	 * Returns the meta object for the containment reference list '{@link FunctionalHazardAnalysis.Trigger_Conditions#getCond <em>Cond</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cond</em>'.
	 * @see FunctionalHazardAnalysis.Trigger_Conditions#getCond()
	 * @see #getTrigger_Conditions()
	 * @generated
	 */
	EReference getTrigger_Conditions_Cond();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	FunctionalHazardAnalysisFactory getFunctionalHazardAnalysisFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link FunctionalHazardAnalysis.impl.FHAImpl <em>FHA</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FunctionalHazardAnalysis.impl.FHAImpl
		 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getFHA()
		 * @generated
		 */
		EClass FHA = eINSTANCE.getFHA();

		/**
		 * The meta object literal for the '<em><b>H</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FHA__H = eINSTANCE.getFHA_H();

		/**
		 * The meta object literal for the '<em><b>Hir</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FHA__HIR = eINSTANCE.getFHA_Hir();

		/**
		 * The meta object literal for the '{@link FunctionalHazardAnalysis.impl.Hazard_Inducing_RequirementImpl <em>Hazard Inducing Requirement</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FunctionalHazardAnalysis.impl.Hazard_Inducing_RequirementImpl
		 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getHazard_Inducing_Requirement()
		 * @generated
		 */
		EClass HAZARD_INDUCING_REQUIREMENT = eINSTANCE.getHazard_Inducing_Requirement();

		/**
		 * The meta object literal for the '<em><b>Element name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HAZARD_INDUCING_REQUIREMENT__ELEMENT_NAME = eINSTANCE.getHazard_Inducing_Requirement_Element_name();

		/**
		 * The meta object literal for the '{@link FunctionalHazardAnalysis.impl.HazardImpl <em>Hazard</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FunctionalHazardAnalysis.impl.HazardImpl
		 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getHazard()
		 * @generated
		 */
		EClass HAZARD = eINSTANCE.getHazard();

		/**
		 * The meta object literal for the '<em><b>HID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HAZARD__HID = eINSTANCE.getHazard_H_ID();

		/**
		 * The meta object literal for the '<em><b>Hname</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HAZARD__HNAME = eINSTANCE.getHazard_H_name();

		/**
		 * The meta object literal for the '<em><b>SG</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HAZARD__SG = eINSTANCE.getHazard_SG();

		/**
		 * The meta object literal for the '<em><b>TC</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HAZARD__TC = eINSTANCE.getHazard_TC();

		/**
		 * The meta object literal for the '<em><b>Relates to</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HAZARD__RELATES_TO = eINSTANCE.getHazard_Relates_to();

		/**
		 * The meta object literal for the '{@link FunctionalHazardAnalysis.impl.Trigger_ConditionImpl <em>Trigger Condition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FunctionalHazardAnalysis.impl.Trigger_ConditionImpl
		 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getTrigger_Condition()
		 * @generated
		 */
		EClass TRIGGER_CONDITION = eINSTANCE.getTrigger_Condition();

		/**
		 * The meta object literal for the '<em><b>TC ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIGGER_CONDITION__TC_ID = eINSTANCE.getTrigger_Condition_TC_ID();

		/**
		 * The meta object literal for the '<em><b>TC name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIGGER_CONDITION__TC_NAME = eINSTANCE.getTrigger_Condition_TC_name();

		/**
		 * The meta object literal for the '{@link FunctionalHazardAnalysis.impl.Safety_GoalImpl <em>Safety Goal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FunctionalHazardAnalysis.impl.Safety_GoalImpl
		 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getSafety_Goal()
		 * @generated
		 */
		EClass SAFETY_GOAL = eINSTANCE.getSafety_Goal();

		/**
		 * The meta object literal for the '<em><b>SG name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SAFETY_GOAL__SG_NAME = eINSTANCE.getSafety_Goal_SG_name();

		/**
		 * The meta object literal for the '<em><b>SG ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SAFETY_GOAL__SG_ID = eINSTANCE.getSafety_Goal_SG_ID();

		/**
		 * The meta object literal for the '{@link FunctionalHazardAnalysis.impl.andnodeImpl <em>andnode</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FunctionalHazardAnalysis.impl.andnodeImpl
		 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getandnode()
		 * @generated
		 */
		EClass ANDNODE = eINSTANCE.getandnode();

		/**
		 * The meta object literal for the '<em><b>And id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANDNODE__AND_ID = eINSTANCE.getandnode_And_id();

		/**
		 * The meta object literal for the '<em><b>Linked by</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANDNODE__LINKED_BY = eINSTANCE.getandnode_Linked_by();

		/**
		 * The meta object literal for the '{@link FunctionalHazardAnalysis.impl.ornodeImpl <em>ornode</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FunctionalHazardAnalysis.impl.ornodeImpl
		 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getornode()
		 * @generated
		 */
		EClass ORNODE = eINSTANCE.getornode();

		/**
		 * The meta object literal for the '<em><b>Or id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORNODE__OR_ID = eINSTANCE.getornode_Or_id();

		/**
		 * The meta object literal for the '<em><b>Linked by</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORNODE__LINKED_BY = eINSTANCE.getornode_Linked_by();

		/**
		 * The meta object literal for the '{@link FunctionalHazardAnalysis.impl.Trigger_ConditionsImpl <em>Trigger Conditions</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FunctionalHazardAnalysis.impl.Trigger_ConditionsImpl
		 * @see FunctionalHazardAnalysis.impl.FunctionalHazardAnalysisPackageImpl#getTrigger_Conditions()
		 * @generated
		 */
		EClass TRIGGER_CONDITIONS = eINSTANCE.getTrigger_Conditions();

		/**
		 * The meta object literal for the '<em><b>Or</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIGGER_CONDITIONS__OR = eINSTANCE.getTrigger_Conditions_Or();

		/**
		 * The meta object literal for the '<em><b>And</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIGGER_CONDITIONS__AND = eINSTANCE.getTrigger_Conditions_And();

		/**
		 * The meta object literal for the '<em><b>Cond</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIGGER_CONDITIONS__COND = eINSTANCE.getTrigger_Conditions_Cond();

	}

} //FunctionalHazardAnalysisPackage
