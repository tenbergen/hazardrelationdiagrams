/**
 */
package FunctionalHazardAnalysis.util;

import FunctionalHazardAnalysis.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage
 * @generated
 */
public class FunctionalHazardAnalysisAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static FunctionalHazardAnalysisPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionalHazardAnalysisAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = FunctionalHazardAnalysisPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FunctionalHazardAnalysisSwitch<Adapter> modelSwitch =
		new FunctionalHazardAnalysisSwitch<Adapter>() {
			@Override
			public Adapter caseFHA(FHA object) {
				return createFHAAdapter();
			}
			@Override
			public Adapter caseHazard_Inducing_Requirement(Hazard_Inducing_Requirement object) {
				return createHazard_Inducing_RequirementAdapter();
			}
			@Override
			public Adapter caseHazard(Hazard object) {
				return createHazardAdapter();
			}
			@Override
			public Adapter caseTrigger_Condition(Trigger_Condition object) {
				return createTrigger_ConditionAdapter();
			}
			@Override
			public Adapter caseSafety_Goal(Safety_Goal object) {
				return createSafety_GoalAdapter();
			}
			@Override
			public Adapter caseandnode(andnode object) {
				return createandnodeAdapter();
			}
			@Override
			public Adapter caseornode(ornode object) {
				return createornodeAdapter();
			}
			@Override
			public Adapter caseTrigger_Conditions(Trigger_Conditions object) {
				return createTrigger_ConditionsAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link FunctionalHazardAnalysis.FHA <em>FHA</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see FunctionalHazardAnalysis.FHA
	 * @generated
	 */
	public Adapter createFHAAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link FunctionalHazardAnalysis.Hazard_Inducing_Requirement <em>Hazard Inducing Requirement</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see FunctionalHazardAnalysis.Hazard_Inducing_Requirement
	 * @generated
	 */
	public Adapter createHazard_Inducing_RequirementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link FunctionalHazardAnalysis.Hazard <em>Hazard</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see FunctionalHazardAnalysis.Hazard
	 * @generated
	 */
	public Adapter createHazardAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link FunctionalHazardAnalysis.Trigger_Condition <em>Trigger Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see FunctionalHazardAnalysis.Trigger_Condition
	 * @generated
	 */
	public Adapter createTrigger_ConditionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link FunctionalHazardAnalysis.Safety_Goal <em>Safety Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see FunctionalHazardAnalysis.Safety_Goal
	 * @generated
	 */
	public Adapter createSafety_GoalAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link FunctionalHazardAnalysis.andnode <em>andnode</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see FunctionalHazardAnalysis.andnode
	 * @generated
	 */
	public Adapter createandnodeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link FunctionalHazardAnalysis.ornode <em>ornode</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see FunctionalHazardAnalysis.ornode
	 * @generated
	 */
	public Adapter createornodeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link FunctionalHazardAnalysis.Trigger_Conditions <em>Trigger Conditions</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see FunctionalHazardAnalysis.Trigger_Conditions
	 * @generated
	 */
	public Adapter createTrigger_ConditionsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //FunctionalHazardAnalysisAdapterFactory
