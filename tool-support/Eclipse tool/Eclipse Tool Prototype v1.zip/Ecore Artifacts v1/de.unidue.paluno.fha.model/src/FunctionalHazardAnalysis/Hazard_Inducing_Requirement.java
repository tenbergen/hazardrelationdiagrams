/**
 */
package FunctionalHazardAnalysis;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hazard Inducing Requirement</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link FunctionalHazardAnalysis.Hazard_Inducing_Requirement#getElement_name <em>Element name</em>}</li>
 * </ul>
 * </p>
 *
 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getHazard_Inducing_Requirement()
 * @model
 * @generated
 */
public interface Hazard_Inducing_Requirement extends EObject {
	/**
	 * Returns the value of the '<em><b>Element name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Element name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Element name</em>' attribute.
	 * @see #setElement_name(String)
	 * @see FunctionalHazardAnalysis.FunctionalHazardAnalysisPackage#getHazard_Inducing_Requirement_Element_name()
	 * @model
	 * @generated
	 */
	String getElement_name();

	/**
	 * Sets the value of the '{@link FunctionalHazardAnalysis.Hazard_Inducing_Requirement#getElement_name <em>Element name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Element name</em>' attribute.
	 * @see #getElement_name()
	 * @generated
	 */
	void setElement_name(String value);

} // Hazard_Inducing_Requirement
