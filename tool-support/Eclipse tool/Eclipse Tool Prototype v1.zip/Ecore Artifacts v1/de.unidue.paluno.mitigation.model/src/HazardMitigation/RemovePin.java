/**
 */
package HazardMitigation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Remove Pin</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link HazardMitigation.RemovePin#getPinName <em>Pin Name</em>}</li>
 *   <li>{@link HazardMitigation.RemovePin#getMitigation <em>Mitigation</em>}</li>
 * </ul>
 * </p>
 *
 * @see HazardMitigation.HazardMitigationPackage#getRemovePin()
 * @model
 * @generated
 */
public interface RemovePin extends Mitigation {
	/**
	 * Returns the value of the '<em><b>Pin Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pin Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pin Name</em>' attribute.
	 * @see #setPinName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getRemovePin_PinName()
	 * @model
	 * @generated
	 */
	String getPinName();

	/**
	 * Sets the value of the '{@link HazardMitigation.RemovePin#getPinName <em>Pin Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pin Name</em>' attribute.
	 * @see #getPinName()
	 * @generated
	 */
	void setPinName(String value);

	/**
	 * Returns the value of the '<em><b>Mitigation</b></em>' attribute.
	 * The default value is <code>"Remove Pin"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mitigation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mitigation</em>' attribute.
	 * @see HazardMitigation.HazardMitigationPackage#getRemovePin_Mitigation()
	 * @model default="Remove Pin" changeable="false"
	 * @generated
	 */
	String getMitigation();

} // RemovePin
