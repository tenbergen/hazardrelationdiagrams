/**
 */
package HazardMitigation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Remove Control Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link HazardMitigation.RemoveControlNode#getNodeType <em>Node Type</em>}</li>
 *   <li>{@link HazardMitigation.RemoveControlNode#getMitigation <em>Mitigation</em>}</li>
 *   <li>{@link HazardMitigation.RemoveControlNode#getNodeName <em>Node Name</em>}</li>
 * </ul>
 * </p>
 *
 * @see HazardMitigation.HazardMitigationPackage#getRemoveControlNode()
 * @model
 * @generated
 */
public interface RemoveControlNode extends Mitigation {
	/**
	 * Returns the value of the '<em><b>Node Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Node Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Node Type</em>' attribute.
	 * @see #setNodeType(String)
	 * @see HazardMitigation.HazardMitigationPackage#getRemoveControlNode_NodeType()
	 * @model
	 * @generated
	 */
	String getNodeType();

	/**
	 * Sets the value of the '{@link HazardMitigation.RemoveControlNode#getNodeType <em>Node Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Node Type</em>' attribute.
	 * @see #getNodeType()
	 * @generated
	 */
	void setNodeType(String value);

	/**
	 * Returns the value of the '<em><b>Mitigation</b></em>' attribute.
	 * The default value is <code>"Remove Control Node"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mitigation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mitigation</em>' attribute.
	 * @see HazardMitigation.HazardMitigationPackage#getRemoveControlNode_Mitigation()
	 * @model default="Remove Control Node" changeable="false"
	 * @generated
	 */
	String getMitigation();

	/**
	 * Returns the value of the '<em><b>Node Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Node Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Node Name</em>' attribute.
	 * @see #setNodeName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getRemoveControlNode_NodeName()
	 * @model
	 * @generated
	 */
	String getNodeName();

	/**
	 * Sets the value of the '{@link HazardMitigation.RemoveControlNode#getNodeName <em>Node Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Node Name</em>' attribute.
	 * @see #getNodeName()
	 * @generated
	 */
	void setNodeName(String value);

} // RemoveControlNode
