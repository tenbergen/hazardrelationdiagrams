/**
 */
package HazardMitigation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Insert Control Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link HazardMitigation.InsertControlNode#getNodeType <em>Node Type</em>}</li>
 *   <li>{@link HazardMitigation.InsertControlNode#getMitigation <em>Mitigation</em>}</li>
 *   <li>{@link HazardMitigation.InsertControlNode#getNodeName <em>Node Name</em>}</li>
 * </ul>
 * </p>
 *
 * @see HazardMitigation.HazardMitigationPackage#getInsertControlNode()
 * @model
 * @generated
 */
public interface InsertControlNode extends Mitigation {
	/**
	 * Returns the value of the '<em><b>Node Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Node Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Node Type</em>' attribute.
	 * @see #setNodeType(String)
	 * @see HazardMitigation.HazardMitigationPackage#getInsertControlNode_NodeType()
	 * @model
	 * @generated
	 */
	String getNodeType();

	/**
	 * Sets the value of the '{@link HazardMitigation.InsertControlNode#getNodeType <em>Node Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Node Type</em>' attribute.
	 * @see #getNodeType()
	 * @generated
	 */
	void setNodeType(String value);

	/**
	 * Returns the value of the '<em><b>Mitigation</b></em>' attribute.
	 * The default value is <code>"Insert Control Node"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mitigation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mitigation</em>' attribute.
	 * @see HazardMitigation.HazardMitigationPackage#getInsertControlNode_Mitigation()
	 * @model default="Insert Control Node" changeable="false"
	 * @generated
	 */
	String getMitigation();

	/**
	 * Returns the value of the '<em><b>Node Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Node Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Node Name</em>' attribute.
	 * @see #setNodeName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getInsertControlNode_NodeName()
	 * @model
	 * @generated
	 */
	String getNodeName();

	/**
	 * Sets the value of the '{@link HazardMitigation.InsertControlNode#getNodeName <em>Node Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Node Name</em>' attribute.
	 * @see #getNodeName()
	 * @generated
	 */
	void setNodeName(String value);

} // InsertControlNode
