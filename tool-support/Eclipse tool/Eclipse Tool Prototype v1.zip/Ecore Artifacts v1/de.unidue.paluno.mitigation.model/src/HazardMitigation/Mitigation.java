/**
 */
package HazardMitigation;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mitigation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link HazardMitigation.Mitigation#getID <em>ID</em>}</li>
 *   <li>{@link HazardMitigation.Mitigation#getTargetedTC <em>Targeted TC</em>}</li>
 * </ul>
 * </p>
 *
 * @see HazardMitigation.HazardMitigationPackage#getMitigation()
 * @model abstract="true"
 * @generated
 */
public interface Mitigation extends EObject {
	/**
	 * Returns the value of the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>ID</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>ID</em>' attribute.
	 * @see #setID(String)
	 * @see HazardMitigation.HazardMitigationPackage#getMitigation_ID()
	 * @model
	 * @generated
	 */
	String getID();

	/**
	 * Sets the value of the '{@link HazardMitigation.Mitigation#getID <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>ID</em>' attribute.
	 * @see #getID()
	 * @generated
	 */
	void setID(String value);

	/**
	 * Returns the value of the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Targeted TC</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Targeted TC</em>' attribute.
	 * @see #setTargetedTC(String)
	 * @see HazardMitigation.HazardMitigationPackage#getMitigation_TargetedTC()
	 * @model
	 * @generated
	 */
	String getTargetedTC();

	/**
	 * Sets the value of the '{@link HazardMitigation.Mitigation#getTargetedTC <em>Targeted TC</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Targeted TC</em>' attribute.
	 * @see #getTargetedTC()
	 * @generated
	 */
	void setTargetedTC(String value);

} // Mitigation
