/**
 */
package HazardMitigation;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see HazardMitigation.HazardMitigationPackage
 * @generated
 */
public interface HazardMitigationFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	HazardMitigationFactory eINSTANCE = HazardMitigation.impl.HazardMitigationFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Mitigation List</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mitigation List</em>'.
	 * @generated
	 */
	MitigationList createMitigationList();

	/**
	 * Returns a new object of class '<em>Insert Activity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Insert Activity</em>'.
	 * @generated
	 */
	InsertActivity createInsertActivity();

	/**
	 * Returns a new object of class '<em>Insert Activity Edge</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Insert Activity Edge</em>'.
	 * @generated
	 */
	InsertActivityEdge createInsertActivityEdge();

	/**
	 * Returns a new object of class '<em>Insert Pin</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Insert Pin</em>'.
	 * @generated
	 */
	InsertPin createInsertPin();

	/**
	 * Returns a new object of class '<em>Insert Control Node</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Insert Control Node</em>'.
	 * @generated
	 */
	InsertControlNode createInsertControlNode();

	/**
	 * Returns a new object of class '<em>Remove Activity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Remove Activity</em>'.
	 * @generated
	 */
	RemoveActivity createRemoveActivity();

	/**
	 * Returns a new object of class '<em>Remove Activity Edge</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Remove Activity Edge</em>'.
	 * @generated
	 */
	RemoveActivityEdge createRemoveActivityEdge();

	/**
	 * Returns a new object of class '<em>Remove Pin</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Remove Pin</em>'.
	 * @generated
	 */
	RemovePin createRemovePin();

	/**
	 * Returns a new object of class '<em>Remove Control Node</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Remove Control Node</em>'.
	 * @generated
	 */
	RemoveControlNode createRemoveControlNode();

	/**
	 * Returns a new object of class '<em>Substitute Activity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Substitute Activity</em>'.
	 * @generated
	 */
	SubstituteActivity createSubstituteActivity();

	/**
	 * Returns a new object of class '<em>Substitute Activity Edge</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Substitute Activity Edge</em>'.
	 * @generated
	 */
	SubstituteActivityEdge createSubstituteActivityEdge();

	/**
	 * Returns a new object of class '<em>Substitute Pin</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Substitute Pin</em>'.
	 * @generated
	 */
	SubstitutePin createSubstitutePin();

	/**
	 * Returns a new object of class '<em>Substitute Control Node</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Substitute Control Node</em>'.
	 * @generated
	 */
	SubstituteControlNode createSubstituteControlNode();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	HazardMitigationPackage getHazardMitigationPackage();

} //HazardMitigationFactory
