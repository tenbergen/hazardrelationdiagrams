/**
 */
package HazardMitigation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Substitute Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link HazardMitigation.SubstituteActivity#getOldActivityName <em>Old Activity Name</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteActivity#getNewActivityName <em>New Activity Name</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteActivity#getMitigation <em>Mitigation</em>}</li>
 * </ul>
 * </p>
 *
 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivity()
 * @model
 * @generated
 */
public interface SubstituteActivity extends Mitigation {
	/**
	 * Returns the value of the '<em><b>Old Activity Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Old Activity Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Old Activity Name</em>' attribute.
	 * @see #setOldActivityName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivity_OldActivityName()
	 * @model
	 * @generated
	 */
	String getOldActivityName();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteActivity#getOldActivityName <em>Old Activity Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Old Activity Name</em>' attribute.
	 * @see #getOldActivityName()
	 * @generated
	 */
	void setOldActivityName(String value);

	/**
	 * Returns the value of the '<em><b>New Activity Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>New Activity Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>New Activity Name</em>' attribute.
	 * @see #setNewActivityName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivity_NewActivityName()
	 * @model
	 * @generated
	 */
	String getNewActivityName();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteActivity#getNewActivityName <em>New Activity Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>New Activity Name</em>' attribute.
	 * @see #getNewActivityName()
	 * @generated
	 */
	void setNewActivityName(String value);

	/**
	 * Returns the value of the '<em><b>Mitigation</b></em>' attribute.
	 * The default value is <code>"Substitute Activity"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mitigation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mitigation</em>' attribute.
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivity_Mitigation()
	 * @model default="Substitute Activity" changeable="false"
	 * @generated
	 */
	String getMitigation();

} // SubstituteActivity
