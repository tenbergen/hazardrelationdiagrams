/**
 */
package HazardMitigation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Substitute Pin</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link HazardMitigation.SubstitutePin#getOldPinName <em>Old Pin Name</em>}</li>
 *   <li>{@link HazardMitigation.SubstitutePin#getNewPinName <em>New Pin Name</em>}</li>
 *   <li>{@link HazardMitigation.SubstitutePin#getMitigation <em>Mitigation</em>}</li>
 * </ul>
 * </p>
 *
 * @see HazardMitigation.HazardMitigationPackage#getSubstitutePin()
 * @model
 * @generated
 */
public interface SubstitutePin extends Mitigation {
	/**
	 * Returns the value of the '<em><b>Old Pin Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Old Pin Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Old Pin Name</em>' attribute.
	 * @see #setOldPinName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstitutePin_OldPinName()
	 * @model
	 * @generated
	 */
	String getOldPinName();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstitutePin#getOldPinName <em>Old Pin Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Old Pin Name</em>' attribute.
	 * @see #getOldPinName()
	 * @generated
	 */
	void setOldPinName(String value);

	/**
	 * Returns the value of the '<em><b>New Pin Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>New Pin Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>New Pin Name</em>' attribute.
	 * @see #setNewPinName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstitutePin_NewPinName()
	 * @model
	 * @generated
	 */
	String getNewPinName();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstitutePin#getNewPinName <em>New Pin Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>New Pin Name</em>' attribute.
	 * @see #getNewPinName()
	 * @generated
	 */
	void setNewPinName(String value);

	/**
	 * Returns the value of the '<em><b>Mitigation</b></em>' attribute.
	 * The default value is <code>"Substitute Pin"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mitigation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mitigation</em>' attribute.
	 * @see HazardMitigation.HazardMitigationPackage#getSubstitutePin_Mitigation()
	 * @model default="Substitute Pin" changeable="false"
	 * @generated
	 */
	String getMitigation();

} // SubstitutePin
