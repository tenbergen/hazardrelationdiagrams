/**
 */
package HazardMitigation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Substitute Control Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link HazardMitigation.SubstituteControlNode#getOldNodeType <em>Old Node Type</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteControlNode#getNewNodeType <em>New Node Type</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteControlNode#getMitigation <em>Mitigation</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteControlNode#getOldNodeName <em>Old Node Name</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteControlNode#getNewNodeName <em>New Node Name</em>}</li>
 * </ul>
 * </p>
 *
 * @see HazardMitigation.HazardMitigationPackage#getSubstituteControlNode()
 * @model
 * @generated
 */
public interface SubstituteControlNode extends Mitigation {
	/**
	 * Returns the value of the '<em><b>Old Node Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Old Node Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Old Node Type</em>' attribute.
	 * @see #setOldNodeType(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteControlNode_OldNodeType()
	 * @model
	 * @generated
	 */
	String getOldNodeType();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteControlNode#getOldNodeType <em>Old Node Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Old Node Type</em>' attribute.
	 * @see #getOldNodeType()
	 * @generated
	 */
	void setOldNodeType(String value);

	/**
	 * Returns the value of the '<em><b>New Node Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>New Node Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>New Node Type</em>' attribute.
	 * @see #setNewNodeType(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteControlNode_NewNodeType()
	 * @model
	 * @generated
	 */
	String getNewNodeType();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteControlNode#getNewNodeType <em>New Node Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>New Node Type</em>' attribute.
	 * @see #getNewNodeType()
	 * @generated
	 */
	void setNewNodeType(String value);

	/**
	 * Returns the value of the '<em><b>Mitigation</b></em>' attribute.
	 * The default value is <code>"Substitute Control Node"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mitigation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mitigation</em>' attribute.
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteControlNode_Mitigation()
	 * @model default="Substitute Control Node" changeable="false"
	 * @generated
	 */
	String getMitigation();

	/**
	 * Returns the value of the '<em><b>Old Node Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Old Node Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Old Node Name</em>' attribute.
	 * @see #setOldNodeName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteControlNode_OldNodeName()
	 * @model
	 * @generated
	 */
	String getOldNodeName();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteControlNode#getOldNodeName <em>Old Node Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Old Node Name</em>' attribute.
	 * @see #getOldNodeName()
	 * @generated
	 */
	void setOldNodeName(String value);

	/**
	 * Returns the value of the '<em><b>New Node Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>New Node Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>New Node Name</em>' attribute.
	 * @see #setNewNodeName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteControlNode_NewNodeName()
	 * @model
	 * @generated
	 */
	String getNewNodeName();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteControlNode#getNewNodeName <em>New Node Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>New Node Name</em>' attribute.
	 * @see #getNewNodeName()
	 * @generated
	 */
	void setNewNodeName(String value);

} // SubstituteControlNode
