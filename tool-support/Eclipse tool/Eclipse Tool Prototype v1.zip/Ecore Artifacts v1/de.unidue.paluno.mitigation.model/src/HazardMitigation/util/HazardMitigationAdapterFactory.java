/**
 */
package HazardMitigation.util;

import HazardMitigation.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see HazardMitigation.HazardMitigationPackage
 * @generated
 */
public class HazardMitigationAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static HazardMitigationPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HazardMitigationAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = HazardMitigationPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HazardMitigationSwitch<Adapter> modelSwitch =
		new HazardMitigationSwitch<Adapter>() {
			@Override
			public Adapter caseMitigationList(MitigationList object) {
				return createMitigationListAdapter();
			}
			@Override
			public Adapter caseMitigation(Mitigation object) {
				return createMitigationAdapter();
			}
			@Override
			public Adapter caseInsertActivity(InsertActivity object) {
				return createInsertActivityAdapter();
			}
			@Override
			public Adapter caseInsertActivityEdge(InsertActivityEdge object) {
				return createInsertActivityEdgeAdapter();
			}
			@Override
			public Adapter caseInsertPin(InsertPin object) {
				return createInsertPinAdapter();
			}
			@Override
			public Adapter caseInsertControlNode(InsertControlNode object) {
				return createInsertControlNodeAdapter();
			}
			@Override
			public Adapter caseRemoveActivity(RemoveActivity object) {
				return createRemoveActivityAdapter();
			}
			@Override
			public Adapter caseRemoveActivityEdge(RemoveActivityEdge object) {
				return createRemoveActivityEdgeAdapter();
			}
			@Override
			public Adapter caseRemovePin(RemovePin object) {
				return createRemovePinAdapter();
			}
			@Override
			public Adapter caseRemoveControlNode(RemoveControlNode object) {
				return createRemoveControlNodeAdapter();
			}
			@Override
			public Adapter caseSubstituteActivity(SubstituteActivity object) {
				return createSubstituteActivityAdapter();
			}
			@Override
			public Adapter caseSubstituteActivityEdge(SubstituteActivityEdge object) {
				return createSubstituteActivityEdgeAdapter();
			}
			@Override
			public Adapter caseSubstitutePin(SubstitutePin object) {
				return createSubstitutePinAdapter();
			}
			@Override
			public Adapter caseSubstituteControlNode(SubstituteControlNode object) {
				return createSubstituteControlNodeAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.MitigationList <em>Mitigation List</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.MitigationList
	 * @generated
	 */
	public Adapter createMitigationListAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.Mitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.Mitigation
	 * @generated
	 */
	public Adapter createMitigationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.InsertActivity <em>Insert Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.InsertActivity
	 * @generated
	 */
	public Adapter createInsertActivityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.InsertActivityEdge <em>Insert Activity Edge</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.InsertActivityEdge
	 * @generated
	 */
	public Adapter createInsertActivityEdgeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.InsertPin <em>Insert Pin</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.InsertPin
	 * @generated
	 */
	public Adapter createInsertPinAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.InsertControlNode <em>Insert Control Node</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.InsertControlNode
	 * @generated
	 */
	public Adapter createInsertControlNodeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.RemoveActivity <em>Remove Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.RemoveActivity
	 * @generated
	 */
	public Adapter createRemoveActivityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.RemoveActivityEdge <em>Remove Activity Edge</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.RemoveActivityEdge
	 * @generated
	 */
	public Adapter createRemoveActivityEdgeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.RemovePin <em>Remove Pin</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.RemovePin
	 * @generated
	 */
	public Adapter createRemovePinAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.RemoveControlNode <em>Remove Control Node</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.RemoveControlNode
	 * @generated
	 */
	public Adapter createRemoveControlNodeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.SubstituteActivity <em>Substitute Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.SubstituteActivity
	 * @generated
	 */
	public Adapter createSubstituteActivityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.SubstituteActivityEdge <em>Substitute Activity Edge</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.SubstituteActivityEdge
	 * @generated
	 */
	public Adapter createSubstituteActivityEdgeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.SubstitutePin <em>Substitute Pin</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.SubstitutePin
	 * @generated
	 */
	public Adapter createSubstitutePinAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link HazardMitigation.SubstituteControlNode <em>Substitute Control Node</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see HazardMitigation.SubstituteControlNode
	 * @generated
	 */
	public Adapter createSubstituteControlNodeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //HazardMitigationAdapterFactory
