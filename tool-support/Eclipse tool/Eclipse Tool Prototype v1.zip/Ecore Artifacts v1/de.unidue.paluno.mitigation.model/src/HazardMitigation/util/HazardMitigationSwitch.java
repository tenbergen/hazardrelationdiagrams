/**
 */
package HazardMitigation.util;

import HazardMitigation.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see HazardMitigation.HazardMitigationPackage
 * @generated
 */
public class HazardMitigationSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static HazardMitigationPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HazardMitigationSwitch() {
		if (modelPackage == null) {
			modelPackage = HazardMitigationPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @parameter ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case HazardMitigationPackage.MITIGATION_LIST: {
				MitigationList mitigationList = (MitigationList)theEObject;
				T result = caseMitigationList(mitigationList);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case HazardMitigationPackage.MITIGATION: {
				Mitigation mitigation = (Mitigation)theEObject;
				T result = caseMitigation(mitigation);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case HazardMitigationPackage.INSERT_ACTIVITY: {
				InsertActivity insertActivity = (InsertActivity)theEObject;
				T result = caseInsertActivity(insertActivity);
				if (result == null) result = caseMitigation(insertActivity);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case HazardMitigationPackage.INSERT_ACTIVITY_EDGE: {
				InsertActivityEdge insertActivityEdge = (InsertActivityEdge)theEObject;
				T result = caseInsertActivityEdge(insertActivityEdge);
				if (result == null) result = caseMitigation(insertActivityEdge);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case HazardMitigationPackage.INSERT_PIN: {
				InsertPin insertPin = (InsertPin)theEObject;
				T result = caseInsertPin(insertPin);
				if (result == null) result = caseMitigation(insertPin);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case HazardMitigationPackage.INSERT_CONTROL_NODE: {
				InsertControlNode insertControlNode = (InsertControlNode)theEObject;
				T result = caseInsertControlNode(insertControlNode);
				if (result == null) result = caseMitigation(insertControlNode);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case HazardMitigationPackage.REMOVE_ACTIVITY: {
				RemoveActivity removeActivity = (RemoveActivity)theEObject;
				T result = caseRemoveActivity(removeActivity);
				if (result == null) result = caseMitigation(removeActivity);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case HazardMitigationPackage.REMOVE_ACTIVITY_EDGE: {
				RemoveActivityEdge removeActivityEdge = (RemoveActivityEdge)theEObject;
				T result = caseRemoveActivityEdge(removeActivityEdge);
				if (result == null) result = caseMitigation(removeActivityEdge);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case HazardMitigationPackage.REMOVE_PIN: {
				RemovePin removePin = (RemovePin)theEObject;
				T result = caseRemovePin(removePin);
				if (result == null) result = caseMitigation(removePin);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case HazardMitigationPackage.REMOVE_CONTROL_NODE: {
				RemoveControlNode removeControlNode = (RemoveControlNode)theEObject;
				T result = caseRemoveControlNode(removeControlNode);
				if (result == null) result = caseMitigation(removeControlNode);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY: {
				SubstituteActivity substituteActivity = (SubstituteActivity)theEObject;
				T result = caseSubstituteActivity(substituteActivity);
				if (result == null) result = caseMitigation(substituteActivity);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE: {
				SubstituteActivityEdge substituteActivityEdge = (SubstituteActivityEdge)theEObject;
				T result = caseSubstituteActivityEdge(substituteActivityEdge);
				if (result == null) result = caseMitigation(substituteActivityEdge);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case HazardMitigationPackage.SUBSTITUTE_PIN: {
				SubstitutePin substitutePin = (SubstitutePin)theEObject;
				T result = caseSubstitutePin(substitutePin);
				if (result == null) result = caseMitigation(substitutePin);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE: {
				SubstituteControlNode substituteControlNode = (SubstituteControlNode)theEObject;
				T result = caseSubstituteControlNode(substituteControlNode);
				if (result == null) result = caseMitigation(substituteControlNode);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Mitigation List</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Mitigation List</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMitigationList(MitigationList object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Mitigation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Mitigation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMitigation(Mitigation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Insert Activity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Insert Activity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInsertActivity(InsertActivity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Insert Activity Edge</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Insert Activity Edge</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInsertActivityEdge(InsertActivityEdge object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Insert Pin</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Insert Pin</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInsertPin(InsertPin object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Insert Control Node</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Insert Control Node</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInsertControlNode(InsertControlNode object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Remove Activity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Remove Activity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRemoveActivity(RemoveActivity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Remove Activity Edge</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Remove Activity Edge</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRemoveActivityEdge(RemoveActivityEdge object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Remove Pin</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Remove Pin</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRemovePin(RemovePin object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Remove Control Node</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Remove Control Node</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRemoveControlNode(RemoveControlNode object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Substitute Activity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Substitute Activity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSubstituteActivity(SubstituteActivity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Substitute Activity Edge</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Substitute Activity Edge</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSubstituteActivityEdge(SubstituteActivityEdge object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Substitute Pin</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Substitute Pin</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSubstitutePin(SubstitutePin object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Substitute Control Node</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Substitute Control Node</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSubstituteControlNode(SubstituteControlNode object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //HazardMitigationSwitch
