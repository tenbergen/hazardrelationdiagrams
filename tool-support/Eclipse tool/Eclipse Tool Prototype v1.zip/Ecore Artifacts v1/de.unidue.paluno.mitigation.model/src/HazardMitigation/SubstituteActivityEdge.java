/**
 */
package HazardMitigation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Substitute Activity Edge</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link HazardMitigation.SubstituteActivityEdge#getOldSourceName <em>Old Source Name</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteActivityEdge#getOldMessage <em>Old Message</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteActivityEdge#getOldGuard <em>Old Guard</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteActivityEdge#getOldTargetName <em>Old Target Name</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteActivityEdge#getNewSourceName <em>New Source Name</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteActivityEdge#getNewMessage <em>New Message</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteActivityEdge#getNewGuard <em>New Guard</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteActivityEdge#getNewTargetName <em>New Target Name</em>}</li>
 *   <li>{@link HazardMitigation.SubstituteActivityEdge#getMitigation <em>Mitigation</em>}</li>
 * </ul>
 * </p>
 *
 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivityEdge()
 * @model
 * @generated
 */
public interface SubstituteActivityEdge extends Mitigation {
	/**
	 * Returns the value of the '<em><b>Old Source Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Old Source Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Old Source Name</em>' attribute.
	 * @see #setOldSourceName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivityEdge_OldSourceName()
	 * @model
	 * @generated
	 */
	String getOldSourceName();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteActivityEdge#getOldSourceName <em>Old Source Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Old Source Name</em>' attribute.
	 * @see #getOldSourceName()
	 * @generated
	 */
	void setOldSourceName(String value);

	/**
	 * Returns the value of the '<em><b>Old Message</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Old Message</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Old Message</em>' attribute.
	 * @see #setOldMessage(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivityEdge_OldMessage()
	 * @model
	 * @generated
	 */
	String getOldMessage();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteActivityEdge#getOldMessage <em>Old Message</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Old Message</em>' attribute.
	 * @see #getOldMessage()
	 * @generated
	 */
	void setOldMessage(String value);

	/**
	 * Returns the value of the '<em><b>Old Guard</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Old Guard</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Old Guard</em>' attribute.
	 * @see #setOldGuard(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivityEdge_OldGuard()
	 * @model
	 * @generated
	 */
	String getOldGuard();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteActivityEdge#getOldGuard <em>Old Guard</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Old Guard</em>' attribute.
	 * @see #getOldGuard()
	 * @generated
	 */
	void setOldGuard(String value);

	/**
	 * Returns the value of the '<em><b>Old Target Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Old Target Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Old Target Name</em>' attribute.
	 * @see #setOldTargetName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivityEdge_OldTargetName()
	 * @model
	 * @generated
	 */
	String getOldTargetName();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteActivityEdge#getOldTargetName <em>Old Target Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Old Target Name</em>' attribute.
	 * @see #getOldTargetName()
	 * @generated
	 */
	void setOldTargetName(String value);

	/**
	 * Returns the value of the '<em><b>New Source Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>New Source Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>New Source Name</em>' attribute.
	 * @see #setNewSourceName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivityEdge_NewSourceName()
	 * @model
	 * @generated
	 */
	String getNewSourceName();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteActivityEdge#getNewSourceName <em>New Source Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>New Source Name</em>' attribute.
	 * @see #getNewSourceName()
	 * @generated
	 */
	void setNewSourceName(String value);

	/**
	 * Returns the value of the '<em><b>New Message</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>New Message</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>New Message</em>' attribute.
	 * @see #setNewMessage(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivityEdge_NewMessage()
	 * @model
	 * @generated
	 */
	String getNewMessage();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteActivityEdge#getNewMessage <em>New Message</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>New Message</em>' attribute.
	 * @see #getNewMessage()
	 * @generated
	 */
	void setNewMessage(String value);

	/**
	 * Returns the value of the '<em><b>New Guard</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>New Guard</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>New Guard</em>' attribute.
	 * @see #setNewGuard(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivityEdge_NewGuard()
	 * @model
	 * @generated
	 */
	String getNewGuard();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteActivityEdge#getNewGuard <em>New Guard</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>New Guard</em>' attribute.
	 * @see #getNewGuard()
	 * @generated
	 */
	void setNewGuard(String value);

	/**
	 * Returns the value of the '<em><b>New Target Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>New Target Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>New Target Name</em>' attribute.
	 * @see #setNewTargetName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivityEdge_NewTargetName()
	 * @model
	 * @generated
	 */
	String getNewTargetName();

	/**
	 * Sets the value of the '{@link HazardMitigation.SubstituteActivityEdge#getNewTargetName <em>New Target Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>New Target Name</em>' attribute.
	 * @see #getNewTargetName()
	 * @generated
	 */
	void setNewTargetName(String value);

	/**
	 * Returns the value of the '<em><b>Mitigation</b></em>' attribute.
	 * The default value is <code>"Substitute Activity Edge"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mitigation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mitigation</em>' attribute.
	 * @see HazardMitigation.HazardMitigationPackage#getSubstituteActivityEdge_Mitigation()
	 * @model default="Substitute Activity Edge" changeable="false"
	 * @generated
	 */
	String getMitigation();

} // SubstituteActivityEdge
