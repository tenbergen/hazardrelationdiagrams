/**
 */
package HazardMitigation;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mitigation List</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link HazardMitigation.MitigationList#getUmlModelFile <em>Uml Model File</em>}</li>
 *   <li>{@link HazardMitigation.MitigationList#getActivityDiagramName <em>Activity Diagram Name</em>}</li>
 *   <li>{@link HazardMitigation.MitigationList#getMitigations <em>Mitigations</em>}</li>
 *   <li>{@link HazardMitigation.MitigationList#getHazard_ID <em>Hazard ID</em>}</li>
 * </ul>
 * </p>
 *
 * @see HazardMitigation.HazardMitigationPackage#getMitigationList()
 * @model
 * @generated
 */
public interface MitigationList extends EObject {
	/**
	 * Returns the value of the '<em><b>Uml Model File</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Uml Model File</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Uml Model File</em>' attribute.
	 * @see #setUmlModelFile(String)
	 * @see HazardMitigation.HazardMitigationPackage#getMitigationList_UmlModelFile()
	 * @model
	 * @generated
	 */
	String getUmlModelFile();

	/**
	 * Sets the value of the '{@link HazardMitigation.MitigationList#getUmlModelFile <em>Uml Model File</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Uml Model File</em>' attribute.
	 * @see #getUmlModelFile()
	 * @generated
	 */
	void setUmlModelFile(String value);

	/**
	 * Returns the value of the '<em><b>Activity Diagram Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Activity Diagram Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Activity Diagram Name</em>' attribute.
	 * @see #setActivityDiagramName(String)
	 * @see HazardMitigation.HazardMitigationPackage#getMitigationList_ActivityDiagramName()
	 * @model
	 * @generated
	 */
	String getActivityDiagramName();

	/**
	 * Sets the value of the '{@link HazardMitigation.MitigationList#getActivityDiagramName <em>Activity Diagram Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Activity Diagram Name</em>' attribute.
	 * @see #getActivityDiagramName()
	 * @generated
	 */
	void setActivityDiagramName(String value);

	/**
	 * Returns the value of the '<em><b>Mitigations</b></em>' containment reference list.
	 * The list contents are of type {@link HazardMitigation.Mitigation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mitigations</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mitigations</em>' containment reference list.
	 * @see HazardMitigation.HazardMitigationPackage#getMitigationList_Mitigations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Mitigation> getMitigations();

	/**
	 * Returns the value of the '<em><b>Hazard ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hazard ID</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hazard ID</em>' attribute.
	 * @see #setHazard_ID(String)
	 * @see HazardMitigation.HazardMitigationPackage#getMitigationList_Hazard_ID()
	 * @model
	 * @generated
	 */
	String getHazard_ID();

	/**
	 * Sets the value of the '{@link HazardMitigation.MitigationList#getHazard_ID <em>Hazard ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Hazard ID</em>' attribute.
	 * @see #getHazard_ID()
	 * @generated
	 */
	void setHazard_ID(String value);

} // MitigationList
