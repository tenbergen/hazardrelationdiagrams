/**
 */
package HazardMitigation;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see HazardMitigation.HazardMitigationFactory
 * @model kind="package"
 * @generated
 */
public interface HazardMitigationPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "HazardMitigation";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.paluno.de/hazardmitigation";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "hm";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	HazardMitigationPackage eINSTANCE = HazardMitigation.impl.HazardMitigationPackageImpl.init();

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.MitigationListImpl <em>Mitigation List</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.MitigationListImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getMitigationList()
	 * @generated
	 */
	int MITIGATION_LIST = 0;

	/**
	 * The feature id for the '<em><b>Uml Model File</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MITIGATION_LIST__UML_MODEL_FILE = 0;

	/**
	 * The feature id for the '<em><b>Activity Diagram Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MITIGATION_LIST__ACTIVITY_DIAGRAM_NAME = 1;

	/**
	 * The feature id for the '<em><b>Mitigations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MITIGATION_LIST__MITIGATIONS = 2;

	/**
	 * The feature id for the '<em><b>Hazard ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MITIGATION_LIST__HAZARD_ID = 3;

	/**
	 * The number of structural features of the '<em>Mitigation List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MITIGATION_LIST_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Mitigation List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MITIGATION_LIST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.MitigationImpl <em>Mitigation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.MitigationImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getMitigation()
	 * @generated
	 */
	int MITIGATION = 1;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MITIGATION__ID = 0;

	/**
	 * The feature id for the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MITIGATION__TARGETED_TC = 1;

	/**
	 * The number of structural features of the '<em>Mitigation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MITIGATION_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Mitigation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MITIGATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.InsertActivityImpl <em>Insert Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.InsertActivityImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getInsertActivity()
	 * @generated
	 */
	int INSERT_ACTIVITY = 2;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY__ID = MITIGATION__ID;

	/**
	 * The feature id for the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY__TARGETED_TC = MITIGATION__TARGETED_TC;

	/**
	 * The feature id for the '<em><b>Activity Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY__ACTIVITY_NAME = MITIGATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Mitigation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY__MITIGATION = MITIGATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Insert Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY_FEATURE_COUNT = MITIGATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Insert Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY_OPERATION_COUNT = MITIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.InsertActivityEdgeImpl <em>Insert Activity Edge</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.InsertActivityEdgeImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getInsertActivityEdge()
	 * @generated
	 */
	int INSERT_ACTIVITY_EDGE = 3;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY_EDGE__ID = MITIGATION__ID;

	/**
	 * The feature id for the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY_EDGE__TARGETED_TC = MITIGATION__TARGETED_TC;

	/**
	 * The feature id for the '<em><b>Source Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY_EDGE__SOURCE_NAME = MITIGATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Message</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY_EDGE__MESSAGE = MITIGATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Guard</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY_EDGE__GUARD = MITIGATION_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Target Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY_EDGE__TARGET_NAME = MITIGATION_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Mitigation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY_EDGE__MITIGATION = MITIGATION_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Insert Activity Edge</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY_EDGE_FEATURE_COUNT = MITIGATION_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Insert Activity Edge</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_ACTIVITY_EDGE_OPERATION_COUNT = MITIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.InsertPinImpl <em>Insert Pin</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.InsertPinImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getInsertPin()
	 * @generated
	 */
	int INSERT_PIN = 4;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_PIN__ID = MITIGATION__ID;

	/**
	 * The feature id for the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_PIN__TARGETED_TC = MITIGATION__TARGETED_TC;

	/**
	 * The feature id for the '<em><b>Pin Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_PIN__PIN_NAME = MITIGATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Mitigation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_PIN__MITIGATION = MITIGATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Insert Pin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_PIN_FEATURE_COUNT = MITIGATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Insert Pin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_PIN_OPERATION_COUNT = MITIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.InsertControlNodeImpl <em>Insert Control Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.InsertControlNodeImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getInsertControlNode()
	 * @generated
	 */
	int INSERT_CONTROL_NODE = 5;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_CONTROL_NODE__ID = MITIGATION__ID;

	/**
	 * The feature id for the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_CONTROL_NODE__TARGETED_TC = MITIGATION__TARGETED_TC;

	/**
	 * The feature id for the '<em><b>Node Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_CONTROL_NODE__NODE_TYPE = MITIGATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Mitigation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_CONTROL_NODE__MITIGATION = MITIGATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Node Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_CONTROL_NODE__NODE_NAME = MITIGATION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Insert Control Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_CONTROL_NODE_FEATURE_COUNT = MITIGATION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Insert Control Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSERT_CONTROL_NODE_OPERATION_COUNT = MITIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.RemoveActivityImpl <em>Remove Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.RemoveActivityImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getRemoveActivity()
	 * @generated
	 */
	int REMOVE_ACTIVITY = 6;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY__ID = MITIGATION__ID;

	/**
	 * The feature id for the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY__TARGETED_TC = MITIGATION__TARGETED_TC;

	/**
	 * The feature id for the '<em><b>Activity Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY__ACTIVITY_NAME = MITIGATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Mitigation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY__MITIGATION = MITIGATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Remove Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY_FEATURE_COUNT = MITIGATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Remove Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY_OPERATION_COUNT = MITIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.RemoveActivityEdgeImpl <em>Remove Activity Edge</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.RemoveActivityEdgeImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getRemoveActivityEdge()
	 * @generated
	 */
	int REMOVE_ACTIVITY_EDGE = 7;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY_EDGE__ID = MITIGATION__ID;

	/**
	 * The feature id for the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY_EDGE__TARGETED_TC = MITIGATION__TARGETED_TC;

	/**
	 * The feature id for the '<em><b>Source Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY_EDGE__SOURCE_NAME = MITIGATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Message</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY_EDGE__MESSAGE = MITIGATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Guard</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY_EDGE__GUARD = MITIGATION_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Target Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY_EDGE__TARGET_NAME = MITIGATION_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Mitigation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY_EDGE__MITIGATION = MITIGATION_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Remove Activity Edge</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY_EDGE_FEATURE_COUNT = MITIGATION_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Remove Activity Edge</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_ACTIVITY_EDGE_OPERATION_COUNT = MITIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.RemovePinImpl <em>Remove Pin</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.RemovePinImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getRemovePin()
	 * @generated
	 */
	int REMOVE_PIN = 8;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_PIN__ID = MITIGATION__ID;

	/**
	 * The feature id for the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_PIN__TARGETED_TC = MITIGATION__TARGETED_TC;

	/**
	 * The feature id for the '<em><b>Pin Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_PIN__PIN_NAME = MITIGATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Mitigation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_PIN__MITIGATION = MITIGATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Remove Pin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_PIN_FEATURE_COUNT = MITIGATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Remove Pin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_PIN_OPERATION_COUNT = MITIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.RemoveControlNodeImpl <em>Remove Control Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.RemoveControlNodeImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getRemoveControlNode()
	 * @generated
	 */
	int REMOVE_CONTROL_NODE = 9;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_CONTROL_NODE__ID = MITIGATION__ID;

	/**
	 * The feature id for the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_CONTROL_NODE__TARGETED_TC = MITIGATION__TARGETED_TC;

	/**
	 * The feature id for the '<em><b>Node Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_CONTROL_NODE__NODE_TYPE = MITIGATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Mitigation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_CONTROL_NODE__MITIGATION = MITIGATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Node Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_CONTROL_NODE__NODE_NAME = MITIGATION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Remove Control Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_CONTROL_NODE_FEATURE_COUNT = MITIGATION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Remove Control Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_CONTROL_NODE_OPERATION_COUNT = MITIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.SubstituteActivityImpl <em>Substitute Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.SubstituteActivityImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getSubstituteActivity()
	 * @generated
	 */
	int SUBSTITUTE_ACTIVITY = 10;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY__ID = MITIGATION__ID;

	/**
	 * The feature id for the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY__TARGETED_TC = MITIGATION__TARGETED_TC;

	/**
	 * The feature id for the '<em><b>Old Activity Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY__OLD_ACTIVITY_NAME = MITIGATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>New Activity Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY__NEW_ACTIVITY_NAME = MITIGATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Mitigation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY__MITIGATION = MITIGATION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Substitute Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_FEATURE_COUNT = MITIGATION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Substitute Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_OPERATION_COUNT = MITIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.SubstituteActivityEdgeImpl <em>Substitute Activity Edge</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.SubstituteActivityEdgeImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getSubstituteActivityEdge()
	 * @generated
	 */
	int SUBSTITUTE_ACTIVITY_EDGE = 11;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_EDGE__ID = MITIGATION__ID;

	/**
	 * The feature id for the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_EDGE__TARGETED_TC = MITIGATION__TARGETED_TC;

	/**
	 * The feature id for the '<em><b>Old Source Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_EDGE__OLD_SOURCE_NAME = MITIGATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Old Message</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_EDGE__OLD_MESSAGE = MITIGATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Old Guard</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_EDGE__OLD_GUARD = MITIGATION_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Old Target Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_EDGE__OLD_TARGET_NAME = MITIGATION_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>New Source Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_EDGE__NEW_SOURCE_NAME = MITIGATION_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>New Message</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_EDGE__NEW_MESSAGE = MITIGATION_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>New Guard</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_EDGE__NEW_GUARD = MITIGATION_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>New Target Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_EDGE__NEW_TARGET_NAME = MITIGATION_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Mitigation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_EDGE__MITIGATION = MITIGATION_FEATURE_COUNT + 8;

	/**
	 * The number of structural features of the '<em>Substitute Activity Edge</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_EDGE_FEATURE_COUNT = MITIGATION_FEATURE_COUNT + 9;

	/**
	 * The number of operations of the '<em>Substitute Activity Edge</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_ACTIVITY_EDGE_OPERATION_COUNT = MITIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.SubstitutePinImpl <em>Substitute Pin</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.SubstitutePinImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getSubstitutePin()
	 * @generated
	 */
	int SUBSTITUTE_PIN = 12;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_PIN__ID = MITIGATION__ID;

	/**
	 * The feature id for the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_PIN__TARGETED_TC = MITIGATION__TARGETED_TC;

	/**
	 * The feature id for the '<em><b>Old Pin Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_PIN__OLD_PIN_NAME = MITIGATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>New Pin Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_PIN__NEW_PIN_NAME = MITIGATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Mitigation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_PIN__MITIGATION = MITIGATION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Substitute Pin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_PIN_FEATURE_COUNT = MITIGATION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Substitute Pin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_PIN_OPERATION_COUNT = MITIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link HazardMitigation.impl.SubstituteControlNodeImpl <em>Substitute Control Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see HazardMitigation.impl.SubstituteControlNodeImpl
	 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getSubstituteControlNode()
	 * @generated
	 */
	int SUBSTITUTE_CONTROL_NODE = 13;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_CONTROL_NODE__ID = MITIGATION__ID;

	/**
	 * The feature id for the '<em><b>Targeted TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_CONTROL_NODE__TARGETED_TC = MITIGATION__TARGETED_TC;

	/**
	 * The feature id for the '<em><b>Old Node Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_CONTROL_NODE__OLD_NODE_TYPE = MITIGATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>New Node Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_CONTROL_NODE__NEW_NODE_TYPE = MITIGATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Mitigation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_CONTROL_NODE__MITIGATION = MITIGATION_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Old Node Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_CONTROL_NODE__OLD_NODE_NAME = MITIGATION_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>New Node Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_CONTROL_NODE__NEW_NODE_NAME = MITIGATION_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Substitute Control Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_CONTROL_NODE_FEATURE_COUNT = MITIGATION_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Substitute Control Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSTITUTE_CONTROL_NODE_OPERATION_COUNT = MITIGATION_OPERATION_COUNT + 0;


	/**
	 * Returns the meta object for class '{@link HazardMitigation.MitigationList <em>Mitigation List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Mitigation List</em>'.
	 * @see HazardMitigation.MitigationList
	 * @generated
	 */
	EClass getMitigationList();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.MitigationList#getUmlModelFile <em>Uml Model File</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Uml Model File</em>'.
	 * @see HazardMitigation.MitigationList#getUmlModelFile()
	 * @see #getMitigationList()
	 * @generated
	 */
	EAttribute getMitigationList_UmlModelFile();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.MitigationList#getActivityDiagramName <em>Activity Diagram Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Activity Diagram Name</em>'.
	 * @see HazardMitigation.MitigationList#getActivityDiagramName()
	 * @see #getMitigationList()
	 * @generated
	 */
	EAttribute getMitigationList_ActivityDiagramName();

	/**
	 * Returns the meta object for the containment reference list '{@link HazardMitigation.MitigationList#getMitigations <em>Mitigations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Mitigations</em>'.
	 * @see HazardMitigation.MitigationList#getMitigations()
	 * @see #getMitigationList()
	 * @generated
	 */
	EReference getMitigationList_Mitigations();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.MitigationList#getHazard_ID <em>Hazard ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Hazard ID</em>'.
	 * @see HazardMitigation.MitigationList#getHazard_ID()
	 * @see #getMitigationList()
	 * @generated
	 */
	EAttribute getMitigationList_Hazard_ID();

	/**
	 * Returns the meta object for class '{@link HazardMitigation.Mitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Mitigation</em>'.
	 * @see HazardMitigation.Mitigation
	 * @generated
	 */
	EClass getMitigation();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.Mitigation#getID <em>ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>ID</em>'.
	 * @see HazardMitigation.Mitigation#getID()
	 * @see #getMitigation()
	 * @generated
	 */
	EAttribute getMitigation_ID();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.Mitigation#getTargetedTC <em>Targeted TC</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Targeted TC</em>'.
	 * @see HazardMitigation.Mitigation#getTargetedTC()
	 * @see #getMitigation()
	 * @generated
	 */
	EAttribute getMitigation_TargetedTC();

	/**
	 * Returns the meta object for class '{@link HazardMitigation.InsertActivity <em>Insert Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Insert Activity</em>'.
	 * @see HazardMitigation.InsertActivity
	 * @generated
	 */
	EClass getInsertActivity();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.InsertActivity#getActivityName <em>Activity Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Activity Name</em>'.
	 * @see HazardMitigation.InsertActivity#getActivityName()
	 * @see #getInsertActivity()
	 * @generated
	 */
	EAttribute getInsertActivity_ActivityName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.InsertActivity#getMitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mitigation</em>'.
	 * @see HazardMitigation.InsertActivity#getMitigation()
	 * @see #getInsertActivity()
	 * @generated
	 */
	EAttribute getInsertActivity_Mitigation();

	/**
	 * Returns the meta object for class '{@link HazardMitigation.InsertActivityEdge <em>Insert Activity Edge</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Insert Activity Edge</em>'.
	 * @see HazardMitigation.InsertActivityEdge
	 * @generated
	 */
	EClass getInsertActivityEdge();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.InsertActivityEdge#getSourceName <em>Source Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Source Name</em>'.
	 * @see HazardMitigation.InsertActivityEdge#getSourceName()
	 * @see #getInsertActivityEdge()
	 * @generated
	 */
	EAttribute getInsertActivityEdge_SourceName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.InsertActivityEdge#getMessage <em>Message</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Message</em>'.
	 * @see HazardMitigation.InsertActivityEdge#getMessage()
	 * @see #getInsertActivityEdge()
	 * @generated
	 */
	EAttribute getInsertActivityEdge_Message();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.InsertActivityEdge#getGuard <em>Guard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Guard</em>'.
	 * @see HazardMitigation.InsertActivityEdge#getGuard()
	 * @see #getInsertActivityEdge()
	 * @generated
	 */
	EAttribute getInsertActivityEdge_Guard();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.InsertActivityEdge#getTargetName <em>Target Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Target Name</em>'.
	 * @see HazardMitigation.InsertActivityEdge#getTargetName()
	 * @see #getInsertActivityEdge()
	 * @generated
	 */
	EAttribute getInsertActivityEdge_TargetName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.InsertActivityEdge#getMitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mitigation</em>'.
	 * @see HazardMitigation.InsertActivityEdge#getMitigation()
	 * @see #getInsertActivityEdge()
	 * @generated
	 */
	EAttribute getInsertActivityEdge_Mitigation();

	/**
	 * Returns the meta object for class '{@link HazardMitigation.InsertPin <em>Insert Pin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Insert Pin</em>'.
	 * @see HazardMitigation.InsertPin
	 * @generated
	 */
	EClass getInsertPin();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.InsertPin#getPinName <em>Pin Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Pin Name</em>'.
	 * @see HazardMitigation.InsertPin#getPinName()
	 * @see #getInsertPin()
	 * @generated
	 */
	EAttribute getInsertPin_PinName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.InsertPin#getMitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mitigation</em>'.
	 * @see HazardMitigation.InsertPin#getMitigation()
	 * @see #getInsertPin()
	 * @generated
	 */
	EAttribute getInsertPin_Mitigation();

	/**
	 * Returns the meta object for class '{@link HazardMitigation.InsertControlNode <em>Insert Control Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Insert Control Node</em>'.
	 * @see HazardMitigation.InsertControlNode
	 * @generated
	 */
	EClass getInsertControlNode();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.InsertControlNode#getNodeType <em>Node Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Node Type</em>'.
	 * @see HazardMitigation.InsertControlNode#getNodeType()
	 * @see #getInsertControlNode()
	 * @generated
	 */
	EAttribute getInsertControlNode_NodeType();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.InsertControlNode#getMitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mitigation</em>'.
	 * @see HazardMitigation.InsertControlNode#getMitigation()
	 * @see #getInsertControlNode()
	 * @generated
	 */
	EAttribute getInsertControlNode_Mitigation();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.InsertControlNode#getNodeName <em>Node Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Node Name</em>'.
	 * @see HazardMitigation.InsertControlNode#getNodeName()
	 * @see #getInsertControlNode()
	 * @generated
	 */
	EAttribute getInsertControlNode_NodeName();

	/**
	 * Returns the meta object for class '{@link HazardMitigation.RemoveActivity <em>Remove Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Remove Activity</em>'.
	 * @see HazardMitigation.RemoveActivity
	 * @generated
	 */
	EClass getRemoveActivity();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.RemoveActivity#getActivityName <em>Activity Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Activity Name</em>'.
	 * @see HazardMitigation.RemoveActivity#getActivityName()
	 * @see #getRemoveActivity()
	 * @generated
	 */
	EAttribute getRemoveActivity_ActivityName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.RemoveActivity#getMitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mitigation</em>'.
	 * @see HazardMitigation.RemoveActivity#getMitigation()
	 * @see #getRemoveActivity()
	 * @generated
	 */
	EAttribute getRemoveActivity_Mitigation();

	/**
	 * Returns the meta object for class '{@link HazardMitigation.RemoveActivityEdge <em>Remove Activity Edge</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Remove Activity Edge</em>'.
	 * @see HazardMitigation.RemoveActivityEdge
	 * @generated
	 */
	EClass getRemoveActivityEdge();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.RemoveActivityEdge#getSourceName <em>Source Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Source Name</em>'.
	 * @see HazardMitigation.RemoveActivityEdge#getSourceName()
	 * @see #getRemoveActivityEdge()
	 * @generated
	 */
	EAttribute getRemoveActivityEdge_SourceName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.RemoveActivityEdge#getMessage <em>Message</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Message</em>'.
	 * @see HazardMitigation.RemoveActivityEdge#getMessage()
	 * @see #getRemoveActivityEdge()
	 * @generated
	 */
	EAttribute getRemoveActivityEdge_Message();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.RemoveActivityEdge#getGuard <em>Guard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Guard</em>'.
	 * @see HazardMitigation.RemoveActivityEdge#getGuard()
	 * @see #getRemoveActivityEdge()
	 * @generated
	 */
	EAttribute getRemoveActivityEdge_Guard();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.RemoveActivityEdge#getTargetName <em>Target Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Target Name</em>'.
	 * @see HazardMitigation.RemoveActivityEdge#getTargetName()
	 * @see #getRemoveActivityEdge()
	 * @generated
	 */
	EAttribute getRemoveActivityEdge_TargetName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.RemoveActivityEdge#getMitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mitigation</em>'.
	 * @see HazardMitigation.RemoveActivityEdge#getMitigation()
	 * @see #getRemoveActivityEdge()
	 * @generated
	 */
	EAttribute getRemoveActivityEdge_Mitigation();

	/**
	 * Returns the meta object for class '{@link HazardMitigation.RemovePin <em>Remove Pin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Remove Pin</em>'.
	 * @see HazardMitigation.RemovePin
	 * @generated
	 */
	EClass getRemovePin();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.RemovePin#getPinName <em>Pin Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Pin Name</em>'.
	 * @see HazardMitigation.RemovePin#getPinName()
	 * @see #getRemovePin()
	 * @generated
	 */
	EAttribute getRemovePin_PinName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.RemovePin#getMitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mitigation</em>'.
	 * @see HazardMitigation.RemovePin#getMitigation()
	 * @see #getRemovePin()
	 * @generated
	 */
	EAttribute getRemovePin_Mitigation();

	/**
	 * Returns the meta object for class '{@link HazardMitigation.RemoveControlNode <em>Remove Control Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Remove Control Node</em>'.
	 * @see HazardMitigation.RemoveControlNode
	 * @generated
	 */
	EClass getRemoveControlNode();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.RemoveControlNode#getNodeType <em>Node Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Node Type</em>'.
	 * @see HazardMitigation.RemoveControlNode#getNodeType()
	 * @see #getRemoveControlNode()
	 * @generated
	 */
	EAttribute getRemoveControlNode_NodeType();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.RemoveControlNode#getMitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mitigation</em>'.
	 * @see HazardMitigation.RemoveControlNode#getMitigation()
	 * @see #getRemoveControlNode()
	 * @generated
	 */
	EAttribute getRemoveControlNode_Mitigation();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.RemoveControlNode#getNodeName <em>Node Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Node Name</em>'.
	 * @see HazardMitigation.RemoveControlNode#getNodeName()
	 * @see #getRemoveControlNode()
	 * @generated
	 */
	EAttribute getRemoveControlNode_NodeName();

	/**
	 * Returns the meta object for class '{@link HazardMitigation.SubstituteActivity <em>Substitute Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Substitute Activity</em>'.
	 * @see HazardMitigation.SubstituteActivity
	 * @generated
	 */
	EClass getSubstituteActivity();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteActivity#getOldActivityName <em>Old Activity Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Old Activity Name</em>'.
	 * @see HazardMitigation.SubstituteActivity#getOldActivityName()
	 * @see #getSubstituteActivity()
	 * @generated
	 */
	EAttribute getSubstituteActivity_OldActivityName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteActivity#getNewActivityName <em>New Activity Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>New Activity Name</em>'.
	 * @see HazardMitigation.SubstituteActivity#getNewActivityName()
	 * @see #getSubstituteActivity()
	 * @generated
	 */
	EAttribute getSubstituteActivity_NewActivityName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteActivity#getMitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mitigation</em>'.
	 * @see HazardMitigation.SubstituteActivity#getMitigation()
	 * @see #getSubstituteActivity()
	 * @generated
	 */
	EAttribute getSubstituteActivity_Mitigation();

	/**
	 * Returns the meta object for class '{@link HazardMitigation.SubstituteActivityEdge <em>Substitute Activity Edge</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Substitute Activity Edge</em>'.
	 * @see HazardMitigation.SubstituteActivityEdge
	 * @generated
	 */
	EClass getSubstituteActivityEdge();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteActivityEdge#getOldSourceName <em>Old Source Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Old Source Name</em>'.
	 * @see HazardMitigation.SubstituteActivityEdge#getOldSourceName()
	 * @see #getSubstituteActivityEdge()
	 * @generated
	 */
	EAttribute getSubstituteActivityEdge_OldSourceName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteActivityEdge#getOldMessage <em>Old Message</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Old Message</em>'.
	 * @see HazardMitigation.SubstituteActivityEdge#getOldMessage()
	 * @see #getSubstituteActivityEdge()
	 * @generated
	 */
	EAttribute getSubstituteActivityEdge_OldMessage();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteActivityEdge#getOldGuard <em>Old Guard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Old Guard</em>'.
	 * @see HazardMitigation.SubstituteActivityEdge#getOldGuard()
	 * @see #getSubstituteActivityEdge()
	 * @generated
	 */
	EAttribute getSubstituteActivityEdge_OldGuard();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteActivityEdge#getOldTargetName <em>Old Target Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Old Target Name</em>'.
	 * @see HazardMitigation.SubstituteActivityEdge#getOldTargetName()
	 * @see #getSubstituteActivityEdge()
	 * @generated
	 */
	EAttribute getSubstituteActivityEdge_OldTargetName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteActivityEdge#getNewSourceName <em>New Source Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>New Source Name</em>'.
	 * @see HazardMitigation.SubstituteActivityEdge#getNewSourceName()
	 * @see #getSubstituteActivityEdge()
	 * @generated
	 */
	EAttribute getSubstituteActivityEdge_NewSourceName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteActivityEdge#getNewMessage <em>New Message</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>New Message</em>'.
	 * @see HazardMitigation.SubstituteActivityEdge#getNewMessage()
	 * @see #getSubstituteActivityEdge()
	 * @generated
	 */
	EAttribute getSubstituteActivityEdge_NewMessage();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteActivityEdge#getNewGuard <em>New Guard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>New Guard</em>'.
	 * @see HazardMitigation.SubstituteActivityEdge#getNewGuard()
	 * @see #getSubstituteActivityEdge()
	 * @generated
	 */
	EAttribute getSubstituteActivityEdge_NewGuard();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteActivityEdge#getNewTargetName <em>New Target Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>New Target Name</em>'.
	 * @see HazardMitigation.SubstituteActivityEdge#getNewTargetName()
	 * @see #getSubstituteActivityEdge()
	 * @generated
	 */
	EAttribute getSubstituteActivityEdge_NewTargetName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteActivityEdge#getMitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mitigation</em>'.
	 * @see HazardMitigation.SubstituteActivityEdge#getMitigation()
	 * @see #getSubstituteActivityEdge()
	 * @generated
	 */
	EAttribute getSubstituteActivityEdge_Mitigation();

	/**
	 * Returns the meta object for class '{@link HazardMitigation.SubstitutePin <em>Substitute Pin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Substitute Pin</em>'.
	 * @see HazardMitigation.SubstitutePin
	 * @generated
	 */
	EClass getSubstitutePin();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstitutePin#getOldPinName <em>Old Pin Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Old Pin Name</em>'.
	 * @see HazardMitigation.SubstitutePin#getOldPinName()
	 * @see #getSubstitutePin()
	 * @generated
	 */
	EAttribute getSubstitutePin_OldPinName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstitutePin#getNewPinName <em>New Pin Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>New Pin Name</em>'.
	 * @see HazardMitigation.SubstitutePin#getNewPinName()
	 * @see #getSubstitutePin()
	 * @generated
	 */
	EAttribute getSubstitutePin_NewPinName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstitutePin#getMitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mitigation</em>'.
	 * @see HazardMitigation.SubstitutePin#getMitigation()
	 * @see #getSubstitutePin()
	 * @generated
	 */
	EAttribute getSubstitutePin_Mitigation();

	/**
	 * Returns the meta object for class '{@link HazardMitigation.SubstituteControlNode <em>Substitute Control Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Substitute Control Node</em>'.
	 * @see HazardMitigation.SubstituteControlNode
	 * @generated
	 */
	EClass getSubstituteControlNode();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteControlNode#getOldNodeType <em>Old Node Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Old Node Type</em>'.
	 * @see HazardMitigation.SubstituteControlNode#getOldNodeType()
	 * @see #getSubstituteControlNode()
	 * @generated
	 */
	EAttribute getSubstituteControlNode_OldNodeType();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteControlNode#getNewNodeType <em>New Node Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>New Node Type</em>'.
	 * @see HazardMitigation.SubstituteControlNode#getNewNodeType()
	 * @see #getSubstituteControlNode()
	 * @generated
	 */
	EAttribute getSubstituteControlNode_NewNodeType();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteControlNode#getMitigation <em>Mitigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mitigation</em>'.
	 * @see HazardMitigation.SubstituteControlNode#getMitigation()
	 * @see #getSubstituteControlNode()
	 * @generated
	 */
	EAttribute getSubstituteControlNode_Mitigation();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteControlNode#getOldNodeName <em>Old Node Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Old Node Name</em>'.
	 * @see HazardMitigation.SubstituteControlNode#getOldNodeName()
	 * @see #getSubstituteControlNode()
	 * @generated
	 */
	EAttribute getSubstituteControlNode_OldNodeName();

	/**
	 * Returns the meta object for the attribute '{@link HazardMitigation.SubstituteControlNode#getNewNodeName <em>New Node Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>New Node Name</em>'.
	 * @see HazardMitigation.SubstituteControlNode#getNewNodeName()
	 * @see #getSubstituteControlNode()
	 * @generated
	 */
	EAttribute getSubstituteControlNode_NewNodeName();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	HazardMitigationFactory getHazardMitigationFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.MitigationListImpl <em>Mitigation List</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.MitigationListImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getMitigationList()
		 * @generated
		 */
		EClass MITIGATION_LIST = eINSTANCE.getMitigationList();

		/**
		 * The meta object literal for the '<em><b>Uml Model File</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MITIGATION_LIST__UML_MODEL_FILE = eINSTANCE.getMitigationList_UmlModelFile();

		/**
		 * The meta object literal for the '<em><b>Activity Diagram Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MITIGATION_LIST__ACTIVITY_DIAGRAM_NAME = eINSTANCE.getMitigationList_ActivityDiagramName();

		/**
		 * The meta object literal for the '<em><b>Mitigations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MITIGATION_LIST__MITIGATIONS = eINSTANCE.getMitigationList_Mitigations();

		/**
		 * The meta object literal for the '<em><b>Hazard ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MITIGATION_LIST__HAZARD_ID = eINSTANCE.getMitigationList_Hazard_ID();

		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.MitigationImpl <em>Mitigation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.MitigationImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getMitigation()
		 * @generated
		 */
		EClass MITIGATION = eINSTANCE.getMitigation();

		/**
		 * The meta object literal for the '<em><b>ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MITIGATION__ID = eINSTANCE.getMitigation_ID();

		/**
		 * The meta object literal for the '<em><b>Targeted TC</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MITIGATION__TARGETED_TC = eINSTANCE.getMitigation_TargetedTC();

		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.InsertActivityImpl <em>Insert Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.InsertActivityImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getInsertActivity()
		 * @generated
		 */
		EClass INSERT_ACTIVITY = eINSTANCE.getInsertActivity();

		/**
		 * The meta object literal for the '<em><b>Activity Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSERT_ACTIVITY__ACTIVITY_NAME = eINSTANCE.getInsertActivity_ActivityName();

		/**
		 * The meta object literal for the '<em><b>Mitigation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSERT_ACTIVITY__MITIGATION = eINSTANCE.getInsertActivity_Mitigation();

		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.InsertActivityEdgeImpl <em>Insert Activity Edge</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.InsertActivityEdgeImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getInsertActivityEdge()
		 * @generated
		 */
		EClass INSERT_ACTIVITY_EDGE = eINSTANCE.getInsertActivityEdge();

		/**
		 * The meta object literal for the '<em><b>Source Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSERT_ACTIVITY_EDGE__SOURCE_NAME = eINSTANCE.getInsertActivityEdge_SourceName();

		/**
		 * The meta object literal for the '<em><b>Message</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSERT_ACTIVITY_EDGE__MESSAGE = eINSTANCE.getInsertActivityEdge_Message();

		/**
		 * The meta object literal for the '<em><b>Guard</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSERT_ACTIVITY_EDGE__GUARD = eINSTANCE.getInsertActivityEdge_Guard();

		/**
		 * The meta object literal for the '<em><b>Target Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSERT_ACTIVITY_EDGE__TARGET_NAME = eINSTANCE.getInsertActivityEdge_TargetName();

		/**
		 * The meta object literal for the '<em><b>Mitigation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSERT_ACTIVITY_EDGE__MITIGATION = eINSTANCE.getInsertActivityEdge_Mitigation();

		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.InsertPinImpl <em>Insert Pin</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.InsertPinImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getInsertPin()
		 * @generated
		 */
		EClass INSERT_PIN = eINSTANCE.getInsertPin();

		/**
		 * The meta object literal for the '<em><b>Pin Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSERT_PIN__PIN_NAME = eINSTANCE.getInsertPin_PinName();

		/**
		 * The meta object literal for the '<em><b>Mitigation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSERT_PIN__MITIGATION = eINSTANCE.getInsertPin_Mitigation();

		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.InsertControlNodeImpl <em>Insert Control Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.InsertControlNodeImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getInsertControlNode()
		 * @generated
		 */
		EClass INSERT_CONTROL_NODE = eINSTANCE.getInsertControlNode();

		/**
		 * The meta object literal for the '<em><b>Node Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSERT_CONTROL_NODE__NODE_TYPE = eINSTANCE.getInsertControlNode_NodeType();

		/**
		 * The meta object literal for the '<em><b>Mitigation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSERT_CONTROL_NODE__MITIGATION = eINSTANCE.getInsertControlNode_Mitigation();

		/**
		 * The meta object literal for the '<em><b>Node Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSERT_CONTROL_NODE__NODE_NAME = eINSTANCE.getInsertControlNode_NodeName();

		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.RemoveActivityImpl <em>Remove Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.RemoveActivityImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getRemoveActivity()
		 * @generated
		 */
		EClass REMOVE_ACTIVITY = eINSTANCE.getRemoveActivity();

		/**
		 * The meta object literal for the '<em><b>Activity Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_ACTIVITY__ACTIVITY_NAME = eINSTANCE.getRemoveActivity_ActivityName();

		/**
		 * The meta object literal for the '<em><b>Mitigation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_ACTIVITY__MITIGATION = eINSTANCE.getRemoveActivity_Mitigation();

		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.RemoveActivityEdgeImpl <em>Remove Activity Edge</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.RemoveActivityEdgeImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getRemoveActivityEdge()
		 * @generated
		 */
		EClass REMOVE_ACTIVITY_EDGE = eINSTANCE.getRemoveActivityEdge();

		/**
		 * The meta object literal for the '<em><b>Source Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_ACTIVITY_EDGE__SOURCE_NAME = eINSTANCE.getRemoveActivityEdge_SourceName();

		/**
		 * The meta object literal for the '<em><b>Message</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_ACTIVITY_EDGE__MESSAGE = eINSTANCE.getRemoveActivityEdge_Message();

		/**
		 * The meta object literal for the '<em><b>Guard</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_ACTIVITY_EDGE__GUARD = eINSTANCE.getRemoveActivityEdge_Guard();

		/**
		 * The meta object literal for the '<em><b>Target Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_ACTIVITY_EDGE__TARGET_NAME = eINSTANCE.getRemoveActivityEdge_TargetName();

		/**
		 * The meta object literal for the '<em><b>Mitigation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_ACTIVITY_EDGE__MITIGATION = eINSTANCE.getRemoveActivityEdge_Mitigation();

		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.RemovePinImpl <em>Remove Pin</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.RemovePinImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getRemovePin()
		 * @generated
		 */
		EClass REMOVE_PIN = eINSTANCE.getRemovePin();

		/**
		 * The meta object literal for the '<em><b>Pin Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_PIN__PIN_NAME = eINSTANCE.getRemovePin_PinName();

		/**
		 * The meta object literal for the '<em><b>Mitigation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_PIN__MITIGATION = eINSTANCE.getRemovePin_Mitigation();

		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.RemoveControlNodeImpl <em>Remove Control Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.RemoveControlNodeImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getRemoveControlNode()
		 * @generated
		 */
		EClass REMOVE_CONTROL_NODE = eINSTANCE.getRemoveControlNode();

		/**
		 * The meta object literal for the '<em><b>Node Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_CONTROL_NODE__NODE_TYPE = eINSTANCE.getRemoveControlNode_NodeType();

		/**
		 * The meta object literal for the '<em><b>Mitigation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_CONTROL_NODE__MITIGATION = eINSTANCE.getRemoveControlNode_Mitigation();

		/**
		 * The meta object literal for the '<em><b>Node Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_CONTROL_NODE__NODE_NAME = eINSTANCE.getRemoveControlNode_NodeName();

		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.SubstituteActivityImpl <em>Substitute Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.SubstituteActivityImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getSubstituteActivity()
		 * @generated
		 */
		EClass SUBSTITUTE_ACTIVITY = eINSTANCE.getSubstituteActivity();

		/**
		 * The meta object literal for the '<em><b>Old Activity Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_ACTIVITY__OLD_ACTIVITY_NAME = eINSTANCE.getSubstituteActivity_OldActivityName();

		/**
		 * The meta object literal for the '<em><b>New Activity Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_ACTIVITY__NEW_ACTIVITY_NAME = eINSTANCE.getSubstituteActivity_NewActivityName();

		/**
		 * The meta object literal for the '<em><b>Mitigation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_ACTIVITY__MITIGATION = eINSTANCE.getSubstituteActivity_Mitigation();

		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.SubstituteActivityEdgeImpl <em>Substitute Activity Edge</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.SubstituteActivityEdgeImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getSubstituteActivityEdge()
		 * @generated
		 */
		EClass SUBSTITUTE_ACTIVITY_EDGE = eINSTANCE.getSubstituteActivityEdge();

		/**
		 * The meta object literal for the '<em><b>Old Source Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_ACTIVITY_EDGE__OLD_SOURCE_NAME = eINSTANCE.getSubstituteActivityEdge_OldSourceName();

		/**
		 * The meta object literal for the '<em><b>Old Message</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_ACTIVITY_EDGE__OLD_MESSAGE = eINSTANCE.getSubstituteActivityEdge_OldMessage();

		/**
		 * The meta object literal for the '<em><b>Old Guard</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_ACTIVITY_EDGE__OLD_GUARD = eINSTANCE.getSubstituteActivityEdge_OldGuard();

		/**
		 * The meta object literal for the '<em><b>Old Target Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_ACTIVITY_EDGE__OLD_TARGET_NAME = eINSTANCE.getSubstituteActivityEdge_OldTargetName();

		/**
		 * The meta object literal for the '<em><b>New Source Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_ACTIVITY_EDGE__NEW_SOURCE_NAME = eINSTANCE.getSubstituteActivityEdge_NewSourceName();

		/**
		 * The meta object literal for the '<em><b>New Message</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_ACTIVITY_EDGE__NEW_MESSAGE = eINSTANCE.getSubstituteActivityEdge_NewMessage();

		/**
		 * The meta object literal for the '<em><b>New Guard</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_ACTIVITY_EDGE__NEW_GUARD = eINSTANCE.getSubstituteActivityEdge_NewGuard();

		/**
		 * The meta object literal for the '<em><b>New Target Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_ACTIVITY_EDGE__NEW_TARGET_NAME = eINSTANCE.getSubstituteActivityEdge_NewTargetName();

		/**
		 * The meta object literal for the '<em><b>Mitigation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_ACTIVITY_EDGE__MITIGATION = eINSTANCE.getSubstituteActivityEdge_Mitigation();

		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.SubstitutePinImpl <em>Substitute Pin</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.SubstitutePinImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getSubstitutePin()
		 * @generated
		 */
		EClass SUBSTITUTE_PIN = eINSTANCE.getSubstitutePin();

		/**
		 * The meta object literal for the '<em><b>Old Pin Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_PIN__OLD_PIN_NAME = eINSTANCE.getSubstitutePin_OldPinName();

		/**
		 * The meta object literal for the '<em><b>New Pin Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_PIN__NEW_PIN_NAME = eINSTANCE.getSubstitutePin_NewPinName();

		/**
		 * The meta object literal for the '<em><b>Mitigation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_PIN__MITIGATION = eINSTANCE.getSubstitutePin_Mitigation();

		/**
		 * The meta object literal for the '{@link HazardMitigation.impl.SubstituteControlNodeImpl <em>Substitute Control Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see HazardMitigation.impl.SubstituteControlNodeImpl
		 * @see HazardMitigation.impl.HazardMitigationPackageImpl#getSubstituteControlNode()
		 * @generated
		 */
		EClass SUBSTITUTE_CONTROL_NODE = eINSTANCE.getSubstituteControlNode();

		/**
		 * The meta object literal for the '<em><b>Old Node Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_CONTROL_NODE__OLD_NODE_TYPE = eINSTANCE.getSubstituteControlNode_OldNodeType();

		/**
		 * The meta object literal for the '<em><b>New Node Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_CONTROL_NODE__NEW_NODE_TYPE = eINSTANCE.getSubstituteControlNode_NewNodeType();

		/**
		 * The meta object literal for the '<em><b>Mitigation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_CONTROL_NODE__MITIGATION = eINSTANCE.getSubstituteControlNode_Mitigation();

		/**
		 * The meta object literal for the '<em><b>Old Node Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_CONTROL_NODE__OLD_NODE_NAME = eINSTANCE.getSubstituteControlNode_OldNodeName();

		/**
		 * The meta object literal for the '<em><b>New Node Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUBSTITUTE_CONTROL_NODE__NEW_NODE_NAME = eINSTANCE.getSubstituteControlNode_NewNodeName();

	}

} //HazardMitigationPackage
