/**
 */
package HazardMitigation.impl;

import HazardMitigation.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class HazardMitigationFactoryImpl extends EFactoryImpl implements HazardMitigationFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static HazardMitigationFactory init() {
		try {
			HazardMitigationFactory theHazardMitigationFactory = (HazardMitigationFactory)EPackage.Registry.INSTANCE.getEFactory(HazardMitigationPackage.eNS_URI);
			if (theHazardMitigationFactory != null) {
				return theHazardMitigationFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new HazardMitigationFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HazardMitigationFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case HazardMitigationPackage.MITIGATION_LIST: return createMitigationList();
			case HazardMitigationPackage.INSERT_ACTIVITY: return createInsertActivity();
			case HazardMitigationPackage.INSERT_ACTIVITY_EDGE: return createInsertActivityEdge();
			case HazardMitigationPackage.INSERT_PIN: return createInsertPin();
			case HazardMitigationPackage.INSERT_CONTROL_NODE: return createInsertControlNode();
			case HazardMitigationPackage.REMOVE_ACTIVITY: return createRemoveActivity();
			case HazardMitigationPackage.REMOVE_ACTIVITY_EDGE: return createRemoveActivityEdge();
			case HazardMitigationPackage.REMOVE_PIN: return createRemovePin();
			case HazardMitigationPackage.REMOVE_CONTROL_NODE: return createRemoveControlNode();
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY: return createSubstituteActivity();
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE: return createSubstituteActivityEdge();
			case HazardMitigationPackage.SUBSTITUTE_PIN: return createSubstitutePin();
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE: return createSubstituteControlNode();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MitigationList createMitigationList() {
		MitigationListImpl mitigationList = new MitigationListImpl();
		return mitigationList;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InsertActivity createInsertActivity() {
		InsertActivityImpl insertActivity = new InsertActivityImpl();
		return insertActivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InsertActivityEdge createInsertActivityEdge() {
		InsertActivityEdgeImpl insertActivityEdge = new InsertActivityEdgeImpl();
		return insertActivityEdge;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InsertPin createInsertPin() {
		InsertPinImpl insertPin = new InsertPinImpl();
		return insertPin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InsertControlNode createInsertControlNode() {
		InsertControlNodeImpl insertControlNode = new InsertControlNodeImpl();
		return insertControlNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RemoveActivity createRemoveActivity() {
		RemoveActivityImpl removeActivity = new RemoveActivityImpl();
		return removeActivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RemoveActivityEdge createRemoveActivityEdge() {
		RemoveActivityEdgeImpl removeActivityEdge = new RemoveActivityEdgeImpl();
		return removeActivityEdge;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RemovePin createRemovePin() {
		RemovePinImpl removePin = new RemovePinImpl();
		return removePin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RemoveControlNode createRemoveControlNode() {
		RemoveControlNodeImpl removeControlNode = new RemoveControlNodeImpl();
		return removeControlNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SubstituteActivity createSubstituteActivity() {
		SubstituteActivityImpl substituteActivity = new SubstituteActivityImpl();
		return substituteActivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SubstituteActivityEdge createSubstituteActivityEdge() {
		SubstituteActivityEdgeImpl substituteActivityEdge = new SubstituteActivityEdgeImpl();
		return substituteActivityEdge;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SubstitutePin createSubstitutePin() {
		SubstitutePinImpl substitutePin = new SubstitutePinImpl();
		return substitutePin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SubstituteControlNode createSubstituteControlNode() {
		SubstituteControlNodeImpl substituteControlNode = new SubstituteControlNodeImpl();
		return substituteControlNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HazardMitigationPackage getHazardMitigationPackage() {
		return (HazardMitigationPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static HazardMitigationPackage getPackage() {
		return HazardMitigationPackage.eINSTANCE;
	}

} //HazardMitigationFactoryImpl
