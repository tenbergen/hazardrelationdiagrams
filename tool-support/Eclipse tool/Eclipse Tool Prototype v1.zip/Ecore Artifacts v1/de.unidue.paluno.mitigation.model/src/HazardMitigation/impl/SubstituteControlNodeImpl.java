/**
 */
package HazardMitigation.impl;

import HazardMitigation.HazardMitigationPackage;
import HazardMitigation.SubstituteControlNode;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Substitute Control Node</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link HazardMitigation.impl.SubstituteControlNodeImpl#getOldNodeType <em>Old Node Type</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteControlNodeImpl#getNewNodeType <em>New Node Type</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteControlNodeImpl#getMitigation <em>Mitigation</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteControlNodeImpl#getOldNodeName <em>Old Node Name</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteControlNodeImpl#getNewNodeName <em>New Node Name</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SubstituteControlNodeImpl extends MitigationImpl implements SubstituteControlNode {
	/**
	 * The default value of the '{@link #getOldNodeType() <em>Old Node Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldNodeType()
	 * @generated
	 * @ordered
	 */
	protected static final String OLD_NODE_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOldNodeType() <em>Old Node Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldNodeType()
	 * @generated
	 * @ordered
	 */
	protected String oldNodeType = OLD_NODE_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getNewNodeType() <em>New Node Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewNodeType()
	 * @generated
	 * @ordered
	 */
	protected static final String NEW_NODE_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNewNodeType() <em>New Node Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewNodeType()
	 * @generated
	 * @ordered
	 */
	protected String newNodeType = NEW_NODE_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getMitigation() <em>Mitigation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMitigation()
	 * @generated
	 * @ordered
	 */
	protected static final String MITIGATION_EDEFAULT = "Substitute Control Node";

	/**
	 * The cached value of the '{@link #getMitigation() <em>Mitigation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMitigation()
	 * @generated
	 * @ordered
	 */
	protected String mitigation = MITIGATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getOldNodeName() <em>Old Node Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldNodeName()
	 * @generated
	 * @ordered
	 */
	protected static final String OLD_NODE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOldNodeName() <em>Old Node Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldNodeName()
	 * @generated
	 * @ordered
	 */
	protected String oldNodeName = OLD_NODE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNewNodeName() <em>New Node Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewNodeName()
	 * @generated
	 * @ordered
	 */
	protected static final String NEW_NODE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNewNodeName() <em>New Node Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewNodeName()
	 * @generated
	 * @ordered
	 */
	protected String newNodeName = NEW_NODE_NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SubstituteControlNodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return HazardMitigationPackage.Literals.SUBSTITUTE_CONTROL_NODE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOldNodeType() {
		return oldNodeType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOldNodeType(String newOldNodeType) {
		String oldOldNodeType = oldNodeType;
		oldNodeType = newOldNodeType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__OLD_NODE_TYPE, oldOldNodeType, oldNodeType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNewNodeType() {
		return newNodeType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNewNodeType(String newNewNodeType) {
		String oldNewNodeType = newNodeType;
		newNodeType = newNewNodeType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__NEW_NODE_TYPE, oldNewNodeType, newNodeType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMitigation() {
		return mitigation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOldNodeName() {
		return oldNodeName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOldNodeName(String newOldNodeName) {
		String oldOldNodeName = oldNodeName;
		oldNodeName = newOldNodeName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__OLD_NODE_NAME, oldOldNodeName, oldNodeName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNewNodeName() {
		return newNodeName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNewNodeName(String newNewNodeName) {
		String oldNewNodeName = newNodeName;
		newNodeName = newNewNodeName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__NEW_NODE_NAME, oldNewNodeName, newNodeName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__OLD_NODE_TYPE:
				return getOldNodeType();
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__NEW_NODE_TYPE:
				return getNewNodeType();
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__MITIGATION:
				return getMitigation();
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__OLD_NODE_NAME:
				return getOldNodeName();
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__NEW_NODE_NAME:
				return getNewNodeName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__OLD_NODE_TYPE:
				setOldNodeType((String)newValue);
				return;
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__NEW_NODE_TYPE:
				setNewNodeType((String)newValue);
				return;
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__OLD_NODE_NAME:
				setOldNodeName((String)newValue);
				return;
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__NEW_NODE_NAME:
				setNewNodeName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__OLD_NODE_TYPE:
				setOldNodeType(OLD_NODE_TYPE_EDEFAULT);
				return;
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__NEW_NODE_TYPE:
				setNewNodeType(NEW_NODE_TYPE_EDEFAULT);
				return;
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__OLD_NODE_NAME:
				setOldNodeName(OLD_NODE_NAME_EDEFAULT);
				return;
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__NEW_NODE_NAME:
				setNewNodeName(NEW_NODE_NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__OLD_NODE_TYPE:
				return OLD_NODE_TYPE_EDEFAULT == null ? oldNodeType != null : !OLD_NODE_TYPE_EDEFAULT.equals(oldNodeType);
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__NEW_NODE_TYPE:
				return NEW_NODE_TYPE_EDEFAULT == null ? newNodeType != null : !NEW_NODE_TYPE_EDEFAULT.equals(newNodeType);
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__MITIGATION:
				return MITIGATION_EDEFAULT == null ? mitigation != null : !MITIGATION_EDEFAULT.equals(mitigation);
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__OLD_NODE_NAME:
				return OLD_NODE_NAME_EDEFAULT == null ? oldNodeName != null : !OLD_NODE_NAME_EDEFAULT.equals(oldNodeName);
			case HazardMitigationPackage.SUBSTITUTE_CONTROL_NODE__NEW_NODE_NAME:
				return NEW_NODE_NAME_EDEFAULT == null ? newNodeName != null : !NEW_NODE_NAME_EDEFAULT.equals(newNodeName);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (oldNodeType: ");
		result.append(oldNodeType);
		result.append(", newNodeType: ");
		result.append(newNodeType);
		result.append(", mitigation: ");
		result.append(mitigation);
		result.append(", oldNodeName: ");
		result.append(oldNodeName);
		result.append(", newNodeName: ");
		result.append(newNodeName);
		result.append(')');
		return result.toString();
	}

} //SubstituteControlNodeImpl
