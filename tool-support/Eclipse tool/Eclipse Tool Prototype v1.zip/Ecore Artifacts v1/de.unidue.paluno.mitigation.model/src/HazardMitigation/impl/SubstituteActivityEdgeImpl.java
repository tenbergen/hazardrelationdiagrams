/**
 */
package HazardMitigation.impl;

import HazardMitigation.HazardMitigationPackage;
import HazardMitigation.SubstituteActivityEdge;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Substitute Activity Edge</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link HazardMitigation.impl.SubstituteActivityEdgeImpl#getOldSourceName <em>Old Source Name</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteActivityEdgeImpl#getOldMessage <em>Old Message</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteActivityEdgeImpl#getOldGuard <em>Old Guard</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteActivityEdgeImpl#getOldTargetName <em>Old Target Name</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteActivityEdgeImpl#getNewSourceName <em>New Source Name</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteActivityEdgeImpl#getNewMessage <em>New Message</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteActivityEdgeImpl#getNewGuard <em>New Guard</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteActivityEdgeImpl#getNewTargetName <em>New Target Name</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteActivityEdgeImpl#getMitigation <em>Mitigation</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SubstituteActivityEdgeImpl extends MitigationImpl implements SubstituteActivityEdge {
	/**
	 * The default value of the '{@link #getOldSourceName() <em>Old Source Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldSourceName()
	 * @generated
	 * @ordered
	 */
	protected static final String OLD_SOURCE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOldSourceName() <em>Old Source Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldSourceName()
	 * @generated
	 * @ordered
	 */
	protected String oldSourceName = OLD_SOURCE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getOldMessage() <em>Old Message</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldMessage()
	 * @generated
	 * @ordered
	 */
	protected static final String OLD_MESSAGE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOldMessage() <em>Old Message</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldMessage()
	 * @generated
	 * @ordered
	 */
	protected String oldMessage = OLD_MESSAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getOldGuard() <em>Old Guard</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldGuard()
	 * @generated
	 * @ordered
	 */
	protected static final String OLD_GUARD_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOldGuard() <em>Old Guard</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldGuard()
	 * @generated
	 * @ordered
	 */
	protected String oldGuard = OLD_GUARD_EDEFAULT;

	/**
	 * The default value of the '{@link #getOldTargetName() <em>Old Target Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldTargetName()
	 * @generated
	 * @ordered
	 */
	protected static final String OLD_TARGET_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOldTargetName() <em>Old Target Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldTargetName()
	 * @generated
	 * @ordered
	 */
	protected String oldTargetName = OLD_TARGET_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNewSourceName() <em>New Source Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewSourceName()
	 * @generated
	 * @ordered
	 */
	protected static final String NEW_SOURCE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNewSourceName() <em>New Source Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewSourceName()
	 * @generated
	 * @ordered
	 */
	protected String newSourceName = NEW_SOURCE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNewMessage() <em>New Message</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewMessage()
	 * @generated
	 * @ordered
	 */
	protected static final String NEW_MESSAGE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNewMessage() <em>New Message</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewMessage()
	 * @generated
	 * @ordered
	 */
	protected String newMessage = NEW_MESSAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getNewGuard() <em>New Guard</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewGuard()
	 * @generated
	 * @ordered
	 */
	protected static final String NEW_GUARD_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNewGuard() <em>New Guard</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewGuard()
	 * @generated
	 * @ordered
	 */
	protected String newGuard = NEW_GUARD_EDEFAULT;

	/**
	 * The default value of the '{@link #getNewTargetName() <em>New Target Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewTargetName()
	 * @generated
	 * @ordered
	 */
	protected static final String NEW_TARGET_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNewTargetName() <em>New Target Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewTargetName()
	 * @generated
	 * @ordered
	 */
	protected String newTargetName = NEW_TARGET_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getMitigation() <em>Mitigation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMitigation()
	 * @generated
	 * @ordered
	 */
	protected static final String MITIGATION_EDEFAULT = "Substitute Activity Edge";

	/**
	 * The cached value of the '{@link #getMitigation() <em>Mitigation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMitigation()
	 * @generated
	 * @ordered
	 */
	protected String mitigation = MITIGATION_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SubstituteActivityEdgeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return HazardMitigationPackage.Literals.SUBSTITUTE_ACTIVITY_EDGE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOldSourceName() {
		return oldSourceName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOldSourceName(String newOldSourceName) {
		String oldOldSourceName = oldSourceName;
		oldSourceName = newOldSourceName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_SOURCE_NAME, oldOldSourceName, oldSourceName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOldMessage() {
		return oldMessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOldMessage(String newOldMessage) {
		String oldOldMessage = oldMessage;
		oldMessage = newOldMessage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_MESSAGE, oldOldMessage, oldMessage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOldGuard() {
		return oldGuard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOldGuard(String newOldGuard) {
		String oldOldGuard = oldGuard;
		oldGuard = newOldGuard;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_GUARD, oldOldGuard, oldGuard));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOldTargetName() {
		return oldTargetName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOldTargetName(String newOldTargetName) {
		String oldOldTargetName = oldTargetName;
		oldTargetName = newOldTargetName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_TARGET_NAME, oldOldTargetName, oldTargetName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNewSourceName() {
		return newSourceName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNewSourceName(String newNewSourceName) {
		String oldNewSourceName = newSourceName;
		newSourceName = newNewSourceName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_SOURCE_NAME, oldNewSourceName, newSourceName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNewMessage() {
		return newMessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNewMessage(String newNewMessage) {
		String oldNewMessage = newMessage;
		newMessage = newNewMessage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_MESSAGE, oldNewMessage, newMessage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNewGuard() {
		return newGuard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNewGuard(String newNewGuard) {
		String oldNewGuard = newGuard;
		newGuard = newNewGuard;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_GUARD, oldNewGuard, newGuard));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNewTargetName() {
		return newTargetName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNewTargetName(String newNewTargetName) {
		String oldNewTargetName = newTargetName;
		newTargetName = newNewTargetName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_TARGET_NAME, oldNewTargetName, newTargetName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMitigation() {
		return mitigation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_SOURCE_NAME:
				return getOldSourceName();
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_MESSAGE:
				return getOldMessage();
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_GUARD:
				return getOldGuard();
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_TARGET_NAME:
				return getOldTargetName();
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_SOURCE_NAME:
				return getNewSourceName();
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_MESSAGE:
				return getNewMessage();
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_GUARD:
				return getNewGuard();
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_TARGET_NAME:
				return getNewTargetName();
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__MITIGATION:
				return getMitigation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_SOURCE_NAME:
				setOldSourceName((String)newValue);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_MESSAGE:
				setOldMessage((String)newValue);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_GUARD:
				setOldGuard((String)newValue);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_TARGET_NAME:
				setOldTargetName((String)newValue);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_SOURCE_NAME:
				setNewSourceName((String)newValue);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_MESSAGE:
				setNewMessage((String)newValue);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_GUARD:
				setNewGuard((String)newValue);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_TARGET_NAME:
				setNewTargetName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_SOURCE_NAME:
				setOldSourceName(OLD_SOURCE_NAME_EDEFAULT);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_MESSAGE:
				setOldMessage(OLD_MESSAGE_EDEFAULT);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_GUARD:
				setOldGuard(OLD_GUARD_EDEFAULT);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_TARGET_NAME:
				setOldTargetName(OLD_TARGET_NAME_EDEFAULT);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_SOURCE_NAME:
				setNewSourceName(NEW_SOURCE_NAME_EDEFAULT);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_MESSAGE:
				setNewMessage(NEW_MESSAGE_EDEFAULT);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_GUARD:
				setNewGuard(NEW_GUARD_EDEFAULT);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_TARGET_NAME:
				setNewTargetName(NEW_TARGET_NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_SOURCE_NAME:
				return OLD_SOURCE_NAME_EDEFAULT == null ? oldSourceName != null : !OLD_SOURCE_NAME_EDEFAULT.equals(oldSourceName);
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_MESSAGE:
				return OLD_MESSAGE_EDEFAULT == null ? oldMessage != null : !OLD_MESSAGE_EDEFAULT.equals(oldMessage);
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_GUARD:
				return OLD_GUARD_EDEFAULT == null ? oldGuard != null : !OLD_GUARD_EDEFAULT.equals(oldGuard);
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__OLD_TARGET_NAME:
				return OLD_TARGET_NAME_EDEFAULT == null ? oldTargetName != null : !OLD_TARGET_NAME_EDEFAULT.equals(oldTargetName);
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_SOURCE_NAME:
				return NEW_SOURCE_NAME_EDEFAULT == null ? newSourceName != null : !NEW_SOURCE_NAME_EDEFAULT.equals(newSourceName);
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_MESSAGE:
				return NEW_MESSAGE_EDEFAULT == null ? newMessage != null : !NEW_MESSAGE_EDEFAULT.equals(newMessage);
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_GUARD:
				return NEW_GUARD_EDEFAULT == null ? newGuard != null : !NEW_GUARD_EDEFAULT.equals(newGuard);
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__NEW_TARGET_NAME:
				return NEW_TARGET_NAME_EDEFAULT == null ? newTargetName != null : !NEW_TARGET_NAME_EDEFAULT.equals(newTargetName);
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY_EDGE__MITIGATION:
				return MITIGATION_EDEFAULT == null ? mitigation != null : !MITIGATION_EDEFAULT.equals(mitigation);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (oldSourceName: ");
		result.append(oldSourceName);
		result.append(", oldMessage: ");
		result.append(oldMessage);
		result.append(", oldGuard: ");
		result.append(oldGuard);
		result.append(", oldTargetName: ");
		result.append(oldTargetName);
		result.append(", newSourceName: ");
		result.append(newSourceName);
		result.append(", newMessage: ");
		result.append(newMessage);
		result.append(", newGuard: ");
		result.append(newGuard);
		result.append(", newTargetName: ");
		result.append(newTargetName);
		result.append(", mitigation: ");
		result.append(mitigation);
		result.append(')');
		return result.toString();
	}

} //SubstituteActivityEdgeImpl
