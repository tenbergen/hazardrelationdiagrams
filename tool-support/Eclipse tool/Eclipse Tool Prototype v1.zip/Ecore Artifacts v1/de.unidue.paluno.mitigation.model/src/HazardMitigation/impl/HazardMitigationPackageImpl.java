/**
 */
package HazardMitigation.impl;

import HazardMitigation.HazardMitigationFactory;
import HazardMitigation.HazardMitigationPackage;
import HazardMitigation.InsertActivity;
import HazardMitigation.InsertActivityEdge;
import HazardMitigation.InsertControlNode;
import HazardMitigation.InsertPin;
import HazardMitigation.Mitigation;
import HazardMitigation.MitigationList;
import HazardMitigation.RemoveActivity;
import HazardMitigation.RemoveActivityEdge;
import HazardMitigation.RemoveControlNode;
import HazardMitigation.RemovePin;
import HazardMitigation.SubstituteActivity;
import HazardMitigation.SubstituteActivityEdge;
import HazardMitigation.SubstituteControlNode;
import HazardMitigation.SubstitutePin;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class HazardMitigationPackageImpl extends EPackageImpl implements HazardMitigationPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mitigationListEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mitigationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass insertActivityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass insertActivityEdgeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass insertPinEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass insertControlNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass removeActivityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass removeActivityEdgeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass removePinEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass removeControlNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass substituteActivityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass substituteActivityEdgeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass substitutePinEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass substituteControlNodeEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see HazardMitigation.HazardMitigationPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private HazardMitigationPackageImpl() {
		super(eNS_URI, HazardMitigationFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link HazardMitigationPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static HazardMitigationPackage init() {
		if (isInited) return (HazardMitigationPackage)EPackage.Registry.INSTANCE.getEPackage(HazardMitigationPackage.eNS_URI);

		// Obtain or create and register package
		HazardMitigationPackageImpl theHazardMitigationPackage = (HazardMitigationPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof HazardMitigationPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new HazardMitigationPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theHazardMitigationPackage.createPackageContents();

		// Initialize created meta-data
		theHazardMitigationPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theHazardMitigationPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(HazardMitigationPackage.eNS_URI, theHazardMitigationPackage);
		return theHazardMitigationPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMitigationList() {
		return mitigationListEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMitigationList_UmlModelFile() {
		return (EAttribute)mitigationListEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMitigationList_ActivityDiagramName() {
		return (EAttribute)mitigationListEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMitigationList_Mitigations() {
		return (EReference)mitigationListEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMitigationList_Hazard_ID() {
		return (EAttribute)mitigationListEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMitigation() {
		return mitigationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMitigation_ID() {
		return (EAttribute)mitigationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMitigation_TargetedTC() {
		return (EAttribute)mitigationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInsertActivity() {
		return insertActivityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInsertActivity_ActivityName() {
		return (EAttribute)insertActivityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInsertActivity_Mitigation() {
		return (EAttribute)insertActivityEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInsertActivityEdge() {
		return insertActivityEdgeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInsertActivityEdge_SourceName() {
		return (EAttribute)insertActivityEdgeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInsertActivityEdge_Message() {
		return (EAttribute)insertActivityEdgeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInsertActivityEdge_Guard() {
		return (EAttribute)insertActivityEdgeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInsertActivityEdge_TargetName() {
		return (EAttribute)insertActivityEdgeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInsertActivityEdge_Mitigation() {
		return (EAttribute)insertActivityEdgeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInsertPin() {
		return insertPinEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInsertPin_PinName() {
		return (EAttribute)insertPinEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInsertPin_Mitigation() {
		return (EAttribute)insertPinEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInsertControlNode() {
		return insertControlNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInsertControlNode_NodeType() {
		return (EAttribute)insertControlNodeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInsertControlNode_Mitigation() {
		return (EAttribute)insertControlNodeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInsertControlNode_NodeName() {
		return (EAttribute)insertControlNodeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRemoveActivity() {
		return removeActivityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemoveActivity_ActivityName() {
		return (EAttribute)removeActivityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemoveActivity_Mitigation() {
		return (EAttribute)removeActivityEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRemoveActivityEdge() {
		return removeActivityEdgeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemoveActivityEdge_SourceName() {
		return (EAttribute)removeActivityEdgeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemoveActivityEdge_Message() {
		return (EAttribute)removeActivityEdgeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemoveActivityEdge_Guard() {
		return (EAttribute)removeActivityEdgeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemoveActivityEdge_TargetName() {
		return (EAttribute)removeActivityEdgeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemoveActivityEdge_Mitigation() {
		return (EAttribute)removeActivityEdgeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRemovePin() {
		return removePinEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemovePin_PinName() {
		return (EAttribute)removePinEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemovePin_Mitigation() {
		return (EAttribute)removePinEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRemoveControlNode() {
		return removeControlNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemoveControlNode_NodeType() {
		return (EAttribute)removeControlNodeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemoveControlNode_Mitigation() {
		return (EAttribute)removeControlNodeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemoveControlNode_NodeName() {
		return (EAttribute)removeControlNodeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSubstituteActivity() {
		return substituteActivityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteActivity_OldActivityName() {
		return (EAttribute)substituteActivityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteActivity_NewActivityName() {
		return (EAttribute)substituteActivityEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteActivity_Mitigation() {
		return (EAttribute)substituteActivityEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSubstituteActivityEdge() {
		return substituteActivityEdgeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteActivityEdge_OldSourceName() {
		return (EAttribute)substituteActivityEdgeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteActivityEdge_OldMessage() {
		return (EAttribute)substituteActivityEdgeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteActivityEdge_OldGuard() {
		return (EAttribute)substituteActivityEdgeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteActivityEdge_OldTargetName() {
		return (EAttribute)substituteActivityEdgeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteActivityEdge_NewSourceName() {
		return (EAttribute)substituteActivityEdgeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteActivityEdge_NewMessage() {
		return (EAttribute)substituteActivityEdgeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteActivityEdge_NewGuard() {
		return (EAttribute)substituteActivityEdgeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteActivityEdge_NewTargetName() {
		return (EAttribute)substituteActivityEdgeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteActivityEdge_Mitigation() {
		return (EAttribute)substituteActivityEdgeEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSubstitutePin() {
		return substitutePinEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstitutePin_OldPinName() {
		return (EAttribute)substitutePinEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstitutePin_NewPinName() {
		return (EAttribute)substitutePinEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstitutePin_Mitigation() {
		return (EAttribute)substitutePinEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSubstituteControlNode() {
		return substituteControlNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteControlNode_OldNodeType() {
		return (EAttribute)substituteControlNodeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteControlNode_NewNodeType() {
		return (EAttribute)substituteControlNodeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteControlNode_Mitigation() {
		return (EAttribute)substituteControlNodeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteControlNode_OldNodeName() {
		return (EAttribute)substituteControlNodeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSubstituteControlNode_NewNodeName() {
		return (EAttribute)substituteControlNodeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HazardMitigationFactory getHazardMitigationFactory() {
		return (HazardMitigationFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		mitigationListEClass = createEClass(MITIGATION_LIST);
		createEAttribute(mitigationListEClass, MITIGATION_LIST__UML_MODEL_FILE);
		createEAttribute(mitigationListEClass, MITIGATION_LIST__ACTIVITY_DIAGRAM_NAME);
		createEReference(mitigationListEClass, MITIGATION_LIST__MITIGATIONS);
		createEAttribute(mitigationListEClass, MITIGATION_LIST__HAZARD_ID);

		mitigationEClass = createEClass(MITIGATION);
		createEAttribute(mitigationEClass, MITIGATION__ID);
		createEAttribute(mitigationEClass, MITIGATION__TARGETED_TC);

		insertActivityEClass = createEClass(INSERT_ACTIVITY);
		createEAttribute(insertActivityEClass, INSERT_ACTIVITY__ACTIVITY_NAME);
		createEAttribute(insertActivityEClass, INSERT_ACTIVITY__MITIGATION);

		insertActivityEdgeEClass = createEClass(INSERT_ACTIVITY_EDGE);
		createEAttribute(insertActivityEdgeEClass, INSERT_ACTIVITY_EDGE__SOURCE_NAME);
		createEAttribute(insertActivityEdgeEClass, INSERT_ACTIVITY_EDGE__MESSAGE);
		createEAttribute(insertActivityEdgeEClass, INSERT_ACTIVITY_EDGE__GUARD);
		createEAttribute(insertActivityEdgeEClass, INSERT_ACTIVITY_EDGE__TARGET_NAME);
		createEAttribute(insertActivityEdgeEClass, INSERT_ACTIVITY_EDGE__MITIGATION);

		insertPinEClass = createEClass(INSERT_PIN);
		createEAttribute(insertPinEClass, INSERT_PIN__PIN_NAME);
		createEAttribute(insertPinEClass, INSERT_PIN__MITIGATION);

		insertControlNodeEClass = createEClass(INSERT_CONTROL_NODE);
		createEAttribute(insertControlNodeEClass, INSERT_CONTROL_NODE__NODE_TYPE);
		createEAttribute(insertControlNodeEClass, INSERT_CONTROL_NODE__MITIGATION);
		createEAttribute(insertControlNodeEClass, INSERT_CONTROL_NODE__NODE_NAME);

		removeActivityEClass = createEClass(REMOVE_ACTIVITY);
		createEAttribute(removeActivityEClass, REMOVE_ACTIVITY__ACTIVITY_NAME);
		createEAttribute(removeActivityEClass, REMOVE_ACTIVITY__MITIGATION);

		removeActivityEdgeEClass = createEClass(REMOVE_ACTIVITY_EDGE);
		createEAttribute(removeActivityEdgeEClass, REMOVE_ACTIVITY_EDGE__SOURCE_NAME);
		createEAttribute(removeActivityEdgeEClass, REMOVE_ACTIVITY_EDGE__MESSAGE);
		createEAttribute(removeActivityEdgeEClass, REMOVE_ACTIVITY_EDGE__GUARD);
		createEAttribute(removeActivityEdgeEClass, REMOVE_ACTIVITY_EDGE__TARGET_NAME);
		createEAttribute(removeActivityEdgeEClass, REMOVE_ACTIVITY_EDGE__MITIGATION);

		removePinEClass = createEClass(REMOVE_PIN);
		createEAttribute(removePinEClass, REMOVE_PIN__PIN_NAME);
		createEAttribute(removePinEClass, REMOVE_PIN__MITIGATION);

		removeControlNodeEClass = createEClass(REMOVE_CONTROL_NODE);
		createEAttribute(removeControlNodeEClass, REMOVE_CONTROL_NODE__NODE_TYPE);
		createEAttribute(removeControlNodeEClass, REMOVE_CONTROL_NODE__MITIGATION);
		createEAttribute(removeControlNodeEClass, REMOVE_CONTROL_NODE__NODE_NAME);

		substituteActivityEClass = createEClass(SUBSTITUTE_ACTIVITY);
		createEAttribute(substituteActivityEClass, SUBSTITUTE_ACTIVITY__OLD_ACTIVITY_NAME);
		createEAttribute(substituteActivityEClass, SUBSTITUTE_ACTIVITY__NEW_ACTIVITY_NAME);
		createEAttribute(substituteActivityEClass, SUBSTITUTE_ACTIVITY__MITIGATION);

		substituteActivityEdgeEClass = createEClass(SUBSTITUTE_ACTIVITY_EDGE);
		createEAttribute(substituteActivityEdgeEClass, SUBSTITUTE_ACTIVITY_EDGE__OLD_SOURCE_NAME);
		createEAttribute(substituteActivityEdgeEClass, SUBSTITUTE_ACTIVITY_EDGE__OLD_MESSAGE);
		createEAttribute(substituteActivityEdgeEClass, SUBSTITUTE_ACTIVITY_EDGE__OLD_GUARD);
		createEAttribute(substituteActivityEdgeEClass, SUBSTITUTE_ACTIVITY_EDGE__OLD_TARGET_NAME);
		createEAttribute(substituteActivityEdgeEClass, SUBSTITUTE_ACTIVITY_EDGE__NEW_SOURCE_NAME);
		createEAttribute(substituteActivityEdgeEClass, SUBSTITUTE_ACTIVITY_EDGE__NEW_MESSAGE);
		createEAttribute(substituteActivityEdgeEClass, SUBSTITUTE_ACTIVITY_EDGE__NEW_GUARD);
		createEAttribute(substituteActivityEdgeEClass, SUBSTITUTE_ACTIVITY_EDGE__NEW_TARGET_NAME);
		createEAttribute(substituteActivityEdgeEClass, SUBSTITUTE_ACTIVITY_EDGE__MITIGATION);

		substitutePinEClass = createEClass(SUBSTITUTE_PIN);
		createEAttribute(substitutePinEClass, SUBSTITUTE_PIN__OLD_PIN_NAME);
		createEAttribute(substitutePinEClass, SUBSTITUTE_PIN__NEW_PIN_NAME);
		createEAttribute(substitutePinEClass, SUBSTITUTE_PIN__MITIGATION);

		substituteControlNodeEClass = createEClass(SUBSTITUTE_CONTROL_NODE);
		createEAttribute(substituteControlNodeEClass, SUBSTITUTE_CONTROL_NODE__OLD_NODE_TYPE);
		createEAttribute(substituteControlNodeEClass, SUBSTITUTE_CONTROL_NODE__NEW_NODE_TYPE);
		createEAttribute(substituteControlNodeEClass, SUBSTITUTE_CONTROL_NODE__MITIGATION);
		createEAttribute(substituteControlNodeEClass, SUBSTITUTE_CONTROL_NODE__OLD_NODE_NAME);
		createEAttribute(substituteControlNodeEClass, SUBSTITUTE_CONTROL_NODE__NEW_NODE_NAME);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		insertActivityEClass.getESuperTypes().add(this.getMitigation());
		insertActivityEdgeEClass.getESuperTypes().add(this.getMitigation());
		insertPinEClass.getESuperTypes().add(this.getMitigation());
		insertControlNodeEClass.getESuperTypes().add(this.getMitigation());
		removeActivityEClass.getESuperTypes().add(this.getMitigation());
		removeActivityEdgeEClass.getESuperTypes().add(this.getMitigation());
		removePinEClass.getESuperTypes().add(this.getMitigation());
		removeControlNodeEClass.getESuperTypes().add(this.getMitigation());
		substituteActivityEClass.getESuperTypes().add(this.getMitigation());
		substituteActivityEdgeEClass.getESuperTypes().add(this.getMitigation());
		substitutePinEClass.getESuperTypes().add(this.getMitigation());
		substituteControlNodeEClass.getESuperTypes().add(this.getMitigation());

		// Initialize classes, features, and operations; add parameters
		initEClass(mitigationListEClass, MitigationList.class, "MitigationList", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMitigationList_UmlModelFile(), ecorePackage.getEString(), "umlModelFile", null, 0, 1, MitigationList.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMitigationList_ActivityDiagramName(), ecorePackage.getEString(), "ActivityDiagramName", null, 0, 1, MitigationList.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMitigationList_Mitigations(), this.getMitigation(), null, "Mitigations", null, 0, -1, MitigationList.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMitigationList_Hazard_ID(), ecorePackage.getEString(), "Hazard_ID", null, 0, 1, MitigationList.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(mitigationEClass, Mitigation.class, "Mitigation", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMitigation_ID(), ecorePackage.getEString(), "ID", null, 0, 1, Mitigation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMitigation_TargetedTC(), ecorePackage.getEString(), "TargetedTC", null, 0, 1, Mitigation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(insertActivityEClass, InsertActivity.class, "InsertActivity", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getInsertActivity_ActivityName(), ecorePackage.getEString(), "activityName", null, 0, 1, InsertActivity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInsertActivity_Mitigation(), ecorePackage.getEString(), "mitigation", "Insert Activity", 0, 1, InsertActivity.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(insertActivityEdgeEClass, InsertActivityEdge.class, "InsertActivityEdge", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getInsertActivityEdge_SourceName(), ecorePackage.getEString(), "SourceName", null, 0, 1, InsertActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInsertActivityEdge_Message(), ecorePackage.getEString(), "Message", null, 0, 1, InsertActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInsertActivityEdge_Guard(), ecorePackage.getEString(), "Guard", null, 0, 1, InsertActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInsertActivityEdge_TargetName(), ecorePackage.getEString(), "targetName", null, 0, 1, InsertActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInsertActivityEdge_Mitigation(), ecorePackage.getEString(), "mitigation", "Insert Activity Edge", 0, 1, InsertActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(insertPinEClass, InsertPin.class, "InsertPin", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getInsertPin_PinName(), ecorePackage.getEString(), "pinName", null, 0, 1, InsertPin.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInsertPin_Mitigation(), ecorePackage.getEString(), "mitigation", "Insert Pin", 0, 1, InsertPin.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(insertControlNodeEClass, InsertControlNode.class, "InsertControlNode", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getInsertControlNode_NodeType(), ecorePackage.getEString(), "nodeType", null, 0, 1, InsertControlNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInsertControlNode_Mitigation(), ecorePackage.getEString(), "mitigation", "Insert Control Node", 0, 1, InsertControlNode.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInsertControlNode_NodeName(), ecorePackage.getEString(), "NodeName", null, 0, 1, InsertControlNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(removeActivityEClass, RemoveActivity.class, "RemoveActivity", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRemoveActivity_ActivityName(), ecorePackage.getEString(), "activityName", null, 0, 1, RemoveActivity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRemoveActivity_Mitigation(), ecorePackage.getEString(), "mitigation", "Remove Activity", 0, 1, RemoveActivity.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(removeActivityEdgeEClass, RemoveActivityEdge.class, "RemoveActivityEdge", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRemoveActivityEdge_SourceName(), ecorePackage.getEString(), "sourceName", null, 0, 1, RemoveActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRemoveActivityEdge_Message(), ecorePackage.getEString(), "message", null, 0, 1, RemoveActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRemoveActivityEdge_Guard(), ecorePackage.getEString(), "Guard", null, 0, 1, RemoveActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRemoveActivityEdge_TargetName(), ecorePackage.getEString(), "targetName", null, 0, 1, RemoveActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRemoveActivityEdge_Mitigation(), ecorePackage.getEString(), "mitigation", "Remove Activity Edge", 0, 1, RemoveActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(removePinEClass, RemovePin.class, "RemovePin", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRemovePin_PinName(), ecorePackage.getEString(), "pinName", null, 0, 1, RemovePin.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRemovePin_Mitigation(), ecorePackage.getEString(), "mitigation", "Remove Pin", 0, 1, RemovePin.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(removeControlNodeEClass, RemoveControlNode.class, "RemoveControlNode", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRemoveControlNode_NodeType(), ecorePackage.getEString(), "nodeType", null, 0, 1, RemoveControlNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRemoveControlNode_Mitigation(), ecorePackage.getEString(), "mitigation", "Remove Control Node", 0, 1, RemoveControlNode.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRemoveControlNode_NodeName(), ecorePackage.getEString(), "NodeName", null, 0, 1, RemoveControlNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(substituteActivityEClass, SubstituteActivity.class, "SubstituteActivity", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSubstituteActivity_OldActivityName(), ecorePackage.getEString(), "oldActivityName", null, 0, 1, SubstituteActivity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteActivity_NewActivityName(), ecorePackage.getEString(), "newActivityName", null, 0, 1, SubstituteActivity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteActivity_Mitigation(), ecorePackage.getEString(), "mitigation", "Substitute Activity", 0, 1, SubstituteActivity.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(substituteActivityEdgeEClass, SubstituteActivityEdge.class, "SubstituteActivityEdge", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSubstituteActivityEdge_OldSourceName(), ecorePackage.getEString(), "oldSourceName", null, 0, 1, SubstituteActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteActivityEdge_OldMessage(), ecorePackage.getEString(), "oldMessage", null, 0, 1, SubstituteActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteActivityEdge_OldGuard(), ecorePackage.getEString(), "oldGuard", null, 0, 1, SubstituteActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteActivityEdge_OldTargetName(), ecorePackage.getEString(), "oldTargetName", null, 0, 1, SubstituteActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteActivityEdge_NewSourceName(), ecorePackage.getEString(), "newSourceName", null, 0, 1, SubstituteActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteActivityEdge_NewMessage(), ecorePackage.getEString(), "newMessage", null, 0, 1, SubstituteActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteActivityEdge_NewGuard(), ecorePackage.getEString(), "newGuard", null, 0, 1, SubstituteActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteActivityEdge_NewTargetName(), ecorePackage.getEString(), "newTargetName", null, 0, 1, SubstituteActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteActivityEdge_Mitigation(), ecorePackage.getEString(), "mitigation", "Substitute Activity Edge", 0, 1, SubstituteActivityEdge.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(substitutePinEClass, SubstitutePin.class, "SubstitutePin", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSubstitutePin_OldPinName(), ecorePackage.getEString(), "oldPinName", null, 0, 1, SubstitutePin.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstitutePin_NewPinName(), ecorePackage.getEString(), "newPinName", null, 0, 1, SubstitutePin.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstitutePin_Mitigation(), ecorePackage.getEString(), "mitigation", "Substitute Pin", 0, 1, SubstitutePin.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(substituteControlNodeEClass, SubstituteControlNode.class, "SubstituteControlNode", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSubstituteControlNode_OldNodeType(), ecorePackage.getEString(), "oldNodeType", null, 0, 1, SubstituteControlNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteControlNode_NewNodeType(), ecorePackage.getEString(), "newNodeType", null, 0, 1, SubstituteControlNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteControlNode_Mitigation(), ecorePackage.getEString(), "mitigation", "Substitute Control Node", 0, 1, SubstituteControlNode.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteControlNode_OldNodeName(), ecorePackage.getEString(), "oldNodeName", null, 0, 1, SubstituteControlNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSubstituteControlNode_NewNodeName(), ecorePackage.getEString(), "newNodeName", null, 0, 1, SubstituteControlNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //HazardMitigationPackageImpl
