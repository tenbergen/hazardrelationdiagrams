/**
 */
package HazardMitigation.impl;

import HazardMitigation.HazardMitigationPackage;
import HazardMitigation.Mitigation;
import HazardMitigation.MitigationList;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Mitigation List</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link HazardMitigation.impl.MitigationListImpl#getUmlModelFile <em>Uml Model File</em>}</li>
 *   <li>{@link HazardMitigation.impl.MitigationListImpl#getActivityDiagramName <em>Activity Diagram Name</em>}</li>
 *   <li>{@link HazardMitigation.impl.MitigationListImpl#getMitigations <em>Mitigations</em>}</li>
 *   <li>{@link HazardMitigation.impl.MitigationListImpl#getHazard_ID <em>Hazard ID</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class MitigationListImpl extends MinimalEObjectImpl.Container implements MitigationList {
	/**
	 * The default value of the '{@link #getUmlModelFile() <em>Uml Model File</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUmlModelFile()
	 * @generated
	 * @ordered
	 */
	protected static final String UML_MODEL_FILE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUmlModelFile() <em>Uml Model File</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUmlModelFile()
	 * @generated
	 * @ordered
	 */
	protected String umlModelFile = UML_MODEL_FILE_EDEFAULT;

	/**
	 * The default value of the '{@link #getActivityDiagramName() <em>Activity Diagram Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActivityDiagramName()
	 * @generated
	 * @ordered
	 */
	protected static final String ACTIVITY_DIAGRAM_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getActivityDiagramName() <em>Activity Diagram Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActivityDiagramName()
	 * @generated
	 * @ordered
	 */
	protected String activityDiagramName = ACTIVITY_DIAGRAM_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getMitigations() <em>Mitigations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMitigations()
	 * @generated
	 * @ordered
	 */
	protected EList<Mitigation> mitigations;

	/**
	 * The default value of the '{@link #getHazard_ID() <em>Hazard ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHazard_ID()
	 * @generated
	 * @ordered
	 */
	protected static final String HAZARD_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHazard_ID() <em>Hazard ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHazard_ID()
	 * @generated
	 * @ordered
	 */
	protected String hazard_ID = HAZARD_ID_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MitigationListImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return HazardMitigationPackage.Literals.MITIGATION_LIST;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getUmlModelFile() {
		return umlModelFile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUmlModelFile(String newUmlModelFile) {
		String oldUmlModelFile = umlModelFile;
		umlModelFile = newUmlModelFile;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.MITIGATION_LIST__UML_MODEL_FILE, oldUmlModelFile, umlModelFile));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getActivityDiagramName() {
		return activityDiagramName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setActivityDiagramName(String newActivityDiagramName) {
		String oldActivityDiagramName = activityDiagramName;
		activityDiagramName = newActivityDiagramName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.MITIGATION_LIST__ACTIVITY_DIAGRAM_NAME, oldActivityDiagramName, activityDiagramName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Mitigation> getMitigations() {
		if (mitigations == null) {
			mitigations = new EObjectContainmentEList<Mitigation>(Mitigation.class, this, HazardMitigationPackage.MITIGATION_LIST__MITIGATIONS);
		}
		return mitigations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getHazard_ID() {
		return hazard_ID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHazard_ID(String newHazard_ID) {
		String oldHazard_ID = hazard_ID;
		hazard_ID = newHazard_ID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.MITIGATION_LIST__HAZARD_ID, oldHazard_ID, hazard_ID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case HazardMitigationPackage.MITIGATION_LIST__MITIGATIONS:
				return ((InternalEList<?>)getMitigations()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case HazardMitigationPackage.MITIGATION_LIST__UML_MODEL_FILE:
				return getUmlModelFile();
			case HazardMitigationPackage.MITIGATION_LIST__ACTIVITY_DIAGRAM_NAME:
				return getActivityDiagramName();
			case HazardMitigationPackage.MITIGATION_LIST__MITIGATIONS:
				return getMitigations();
			case HazardMitigationPackage.MITIGATION_LIST__HAZARD_ID:
				return getHazard_ID();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case HazardMitigationPackage.MITIGATION_LIST__UML_MODEL_FILE:
				setUmlModelFile((String)newValue);
				return;
			case HazardMitigationPackage.MITIGATION_LIST__ACTIVITY_DIAGRAM_NAME:
				setActivityDiagramName((String)newValue);
				return;
			case HazardMitigationPackage.MITIGATION_LIST__MITIGATIONS:
				getMitigations().clear();
				getMitigations().addAll((Collection<? extends Mitigation>)newValue);
				return;
			case HazardMitigationPackage.MITIGATION_LIST__HAZARD_ID:
				setHazard_ID((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case HazardMitigationPackage.MITIGATION_LIST__UML_MODEL_FILE:
				setUmlModelFile(UML_MODEL_FILE_EDEFAULT);
				return;
			case HazardMitigationPackage.MITIGATION_LIST__ACTIVITY_DIAGRAM_NAME:
				setActivityDiagramName(ACTIVITY_DIAGRAM_NAME_EDEFAULT);
				return;
			case HazardMitigationPackage.MITIGATION_LIST__MITIGATIONS:
				getMitigations().clear();
				return;
			case HazardMitigationPackage.MITIGATION_LIST__HAZARD_ID:
				setHazard_ID(HAZARD_ID_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case HazardMitigationPackage.MITIGATION_LIST__UML_MODEL_FILE:
				return UML_MODEL_FILE_EDEFAULT == null ? umlModelFile != null : !UML_MODEL_FILE_EDEFAULT.equals(umlModelFile);
			case HazardMitigationPackage.MITIGATION_LIST__ACTIVITY_DIAGRAM_NAME:
				return ACTIVITY_DIAGRAM_NAME_EDEFAULT == null ? activityDiagramName != null : !ACTIVITY_DIAGRAM_NAME_EDEFAULT.equals(activityDiagramName);
			case HazardMitigationPackage.MITIGATION_LIST__MITIGATIONS:
				return mitigations != null && !mitigations.isEmpty();
			case HazardMitigationPackage.MITIGATION_LIST__HAZARD_ID:
				return HAZARD_ID_EDEFAULT == null ? hazard_ID != null : !HAZARD_ID_EDEFAULT.equals(hazard_ID);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (umlModelFile: ");
		result.append(umlModelFile);
		result.append(", ActivityDiagramName: ");
		result.append(activityDiagramName);
		result.append(", Hazard_ID: ");
		result.append(hazard_ID);
		result.append(')');
		return result.toString();
	}

} //MitigationListImpl
