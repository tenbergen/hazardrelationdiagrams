/**
 */
package HazardMitigation.impl;

import HazardMitigation.HazardMitigationPackage;
import HazardMitigation.SubstituteActivity;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Substitute Activity</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link HazardMitigation.impl.SubstituteActivityImpl#getOldActivityName <em>Old Activity Name</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteActivityImpl#getNewActivityName <em>New Activity Name</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstituteActivityImpl#getMitigation <em>Mitigation</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SubstituteActivityImpl extends MitigationImpl implements SubstituteActivity {
	/**
	 * The default value of the '{@link #getOldActivityName() <em>Old Activity Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldActivityName()
	 * @generated
	 * @ordered
	 */
	protected static final String OLD_ACTIVITY_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOldActivityName() <em>Old Activity Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldActivityName()
	 * @generated
	 * @ordered
	 */
	protected String oldActivityName = OLD_ACTIVITY_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNewActivityName() <em>New Activity Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewActivityName()
	 * @generated
	 * @ordered
	 */
	protected static final String NEW_ACTIVITY_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNewActivityName() <em>New Activity Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewActivityName()
	 * @generated
	 * @ordered
	 */
	protected String newActivityName = NEW_ACTIVITY_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getMitigation() <em>Mitigation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMitigation()
	 * @generated
	 * @ordered
	 */
	protected static final String MITIGATION_EDEFAULT = "Substitute Activity";

	/**
	 * The cached value of the '{@link #getMitigation() <em>Mitigation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMitigation()
	 * @generated
	 * @ordered
	 */
	protected String mitigation = MITIGATION_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SubstituteActivityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return HazardMitigationPackage.Literals.SUBSTITUTE_ACTIVITY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOldActivityName() {
		return oldActivityName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOldActivityName(String newOldActivityName) {
		String oldOldActivityName = oldActivityName;
		oldActivityName = newOldActivityName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_ACTIVITY__OLD_ACTIVITY_NAME, oldOldActivityName, oldActivityName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNewActivityName() {
		return newActivityName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNewActivityName(String newNewActivityName) {
		String oldNewActivityName = newActivityName;
		newActivityName = newNewActivityName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_ACTIVITY__NEW_ACTIVITY_NAME, oldNewActivityName, newActivityName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMitigation() {
		return mitigation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY__OLD_ACTIVITY_NAME:
				return getOldActivityName();
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY__NEW_ACTIVITY_NAME:
				return getNewActivityName();
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY__MITIGATION:
				return getMitigation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY__OLD_ACTIVITY_NAME:
				setOldActivityName((String)newValue);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY__NEW_ACTIVITY_NAME:
				setNewActivityName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY__OLD_ACTIVITY_NAME:
				setOldActivityName(OLD_ACTIVITY_NAME_EDEFAULT);
				return;
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY__NEW_ACTIVITY_NAME:
				setNewActivityName(NEW_ACTIVITY_NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY__OLD_ACTIVITY_NAME:
				return OLD_ACTIVITY_NAME_EDEFAULT == null ? oldActivityName != null : !OLD_ACTIVITY_NAME_EDEFAULT.equals(oldActivityName);
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY__NEW_ACTIVITY_NAME:
				return NEW_ACTIVITY_NAME_EDEFAULT == null ? newActivityName != null : !NEW_ACTIVITY_NAME_EDEFAULT.equals(newActivityName);
			case HazardMitigationPackage.SUBSTITUTE_ACTIVITY__MITIGATION:
				return MITIGATION_EDEFAULT == null ? mitigation != null : !MITIGATION_EDEFAULT.equals(mitigation);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (oldActivityName: ");
		result.append(oldActivityName);
		result.append(", newActivityName: ");
		result.append(newActivityName);
		result.append(", mitigation: ");
		result.append(mitigation);
		result.append(')');
		return result.toString();
	}

} //SubstituteActivityImpl
