/**
 */
package HazardMitigation.impl;

import HazardMitigation.HazardMitigationPackage;
import HazardMitigation.SubstitutePin;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Substitute Pin</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link HazardMitigation.impl.SubstitutePinImpl#getOldPinName <em>Old Pin Name</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstitutePinImpl#getNewPinName <em>New Pin Name</em>}</li>
 *   <li>{@link HazardMitigation.impl.SubstitutePinImpl#getMitigation <em>Mitigation</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SubstitutePinImpl extends MitigationImpl implements SubstitutePin {
	/**
	 * The default value of the '{@link #getOldPinName() <em>Old Pin Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldPinName()
	 * @generated
	 * @ordered
	 */
	protected static final String OLD_PIN_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOldPinName() <em>Old Pin Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOldPinName()
	 * @generated
	 * @ordered
	 */
	protected String oldPinName = OLD_PIN_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNewPinName() <em>New Pin Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewPinName()
	 * @generated
	 * @ordered
	 */
	protected static final String NEW_PIN_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNewPinName() <em>New Pin Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNewPinName()
	 * @generated
	 * @ordered
	 */
	protected String newPinName = NEW_PIN_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getMitigation() <em>Mitigation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMitigation()
	 * @generated
	 * @ordered
	 */
	protected static final String MITIGATION_EDEFAULT = "Substitute Pin";

	/**
	 * The cached value of the '{@link #getMitigation() <em>Mitigation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMitigation()
	 * @generated
	 * @ordered
	 */
	protected String mitigation = MITIGATION_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SubstitutePinImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return HazardMitigationPackage.Literals.SUBSTITUTE_PIN;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOldPinName() {
		return oldPinName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOldPinName(String newOldPinName) {
		String oldOldPinName = oldPinName;
		oldPinName = newOldPinName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_PIN__OLD_PIN_NAME, oldOldPinName, oldPinName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNewPinName() {
		return newPinName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNewPinName(String newNewPinName) {
		String oldNewPinName = newPinName;
		newPinName = newNewPinName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, HazardMitigationPackage.SUBSTITUTE_PIN__NEW_PIN_NAME, oldNewPinName, newPinName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMitigation() {
		return mitigation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_PIN__OLD_PIN_NAME:
				return getOldPinName();
			case HazardMitigationPackage.SUBSTITUTE_PIN__NEW_PIN_NAME:
				return getNewPinName();
			case HazardMitigationPackage.SUBSTITUTE_PIN__MITIGATION:
				return getMitigation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_PIN__OLD_PIN_NAME:
				setOldPinName((String)newValue);
				return;
			case HazardMitigationPackage.SUBSTITUTE_PIN__NEW_PIN_NAME:
				setNewPinName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_PIN__OLD_PIN_NAME:
				setOldPinName(OLD_PIN_NAME_EDEFAULT);
				return;
			case HazardMitigationPackage.SUBSTITUTE_PIN__NEW_PIN_NAME:
				setNewPinName(NEW_PIN_NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case HazardMitigationPackage.SUBSTITUTE_PIN__OLD_PIN_NAME:
				return OLD_PIN_NAME_EDEFAULT == null ? oldPinName != null : !OLD_PIN_NAME_EDEFAULT.equals(oldPinName);
			case HazardMitigationPackage.SUBSTITUTE_PIN__NEW_PIN_NAME:
				return NEW_PIN_NAME_EDEFAULT == null ? newPinName != null : !NEW_PIN_NAME_EDEFAULT.equals(newPinName);
			case HazardMitigationPackage.SUBSTITUTE_PIN__MITIGATION:
				return MITIGATION_EDEFAULT == null ? mitigation != null : !MITIGATION_EDEFAULT.equals(mitigation);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (oldPinName: ");
		result.append(oldPinName);
		result.append(", newPinName: ");
		result.append(newPinName);
		result.append(", mitigation: ");
		result.append(mitigation);
		result.append(')');
		return result.toString();
	}

} //SubstitutePinImpl
